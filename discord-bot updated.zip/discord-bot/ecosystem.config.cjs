// PM2 Ecosystem Config for Svarog Tracer Bot
// 
// SETUP (first time on host):
//   npm install -g pm2
//   pm2 start ecosystem.config.cjs
//   pm2 startup          ← follow the printed command to auto-start on reboot
//   pm2 save             ← persist the process list
//
// DAILY COMMANDS:
//   pm2 status           ← see bot health
//   pm2 logs svarog-bot  ← live logs
//   pm2 restart svarog-bot
//   pm2 stop svarog-bot

module.exports = {
  apps: [
    {
      name: 'svarog-bot',
      script: 'index.js',

      // --- Crash Recovery ---
      autorestart: true,          // Restart automatically if the process exits
      max_restarts: 10,           // Stop trying after 10 rapid crashes (prevents restart loops)
      min_uptime: '30s',          // Must stay alive 30s to count as "stable"
      restart_delay: 5000,        // Wait 5s between crash restarts

      // --- Memory / CPU Guard ---
      // Restarts the bot before the host force-kills it due to high memory
      max_memory_restart: '300M',

      // --- Scheduled Restart (Optional) ---
      // Restarts once per day at 4:00 AM to clear any slow memory leaks.
      // Remove or comment out if you'd prefer pure crash-only restarts.
      cron_restart: '0 4 * * *',

      // --- Logging ---
      out_file: './logs/bot-out.log',
      error_file: './logs/bot-err.log',
      merge_logs: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      log_rotate: true,

      // --- Environment ---
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
