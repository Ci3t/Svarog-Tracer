import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createSession, getSession, endSession, getSessionStats } from '../utils/sessionManager.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-longstring')
		.setDescription('Manage longstring prediction session')
		.addSubcommand(subcommand =>
			subcommand
				.setName('start')
				.setDescription('Start a new longstring session')
				.addStringOption(option =>
					option.setName('timer')
						.setDescription('Session timer (default: 5min)')
						.setRequired(false)
						.addChoices(
							{ name: '5 minutes (default)', value: '5' },
							{ name: 'No timer (manual end only)', value: 'none' }
						)))
		.addSubcommand(subcommand =>
			subcommand
				.setName('end')
				.setDescription('End your current longstring session'))
		.addSubcommand(subcommand =>
			subcommand
				.setName('status')
				.setDescription('Check current longstring session status')),
	
	async execute(interaction) {
		const subcommand = interaction.options.getSubcommand();
		const userId = interaction.user.id;
		
		if (subcommand === 'start') {
			// Check if user already has an active session
			const existingSession = getSession(userId);
			if (existingSession) {
				return interaction.reply({
					content: '⚠️ You already have an active session! Use `/st-longstring end` or `/st-session end` to finish it first.',
					ephemeral: true
				});
			}
			
			// Get timer option
			const timerOption = interaction.options.getString('timer') || '5';
			const hasTimer = timerOption !== 'none';
			const timerMinutes = hasTimer ? parseInt(timerOption) : 0;
			
			// Create new longstring session
			createSession(userId, { 
				hasTimer, 
				timerMinutes, 
				mode: 'longstring',
				user: interaction.user,
			channelId: interaction.channel.id
			});
			
			const timerText = hasTimer 
				? `Session expires after ${timerMinutes} minutes.`
				: 'No timer - session continues until you end it manually.';
			
			const row = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId('set_response_channel')
						.setLabel('📱 Channel Output')
						.setStyle(ButtonStyle.Success)
						.setDisabled(true), // Default choice
					new ButtonBuilder()
						.setCustomId('set_response_dm')
						.setLabel('📬 DM Output')
						.setStyle(ButtonStyle.Secondary)
				);

			return interaction.reply({
				embeds: [{
					color: 0x10b981, // emerald
					title: '🧪 Longstring Session Started',
					description: 'Type your longstring in this channel (e.g., `32134` or `4242323`)\n\n' +
					             '**How it works:**\n' +
					             '• String like `32134` = rolls: 3→2→1→3→4\n' +
					             '• Pairs: `32`, `21`, `13`, `34`, `41`\n' +
					             '• Decoded: `43`, `43`, `42`, `41`, `41`\n\n' +
					             '**Predictions start after 6 rolls**\n' +
					             timerText,
					fields: [
						{ name: '📝 Progress', value: '`▱▱▱▱▱▱` 0/6 rolls', inline: false },
						{ name: '⏱️ Timer', value: hasTimer ? `${timerMinutes} minutes` : 'Disabled', inline: true },
						{ name: '🔒 Privacy', value: 'Ephemeral (only you see this)', inline: true }
					],
					footer: { text: 'Svarog Tracer • Longstring Mode' },
					timestamp: new Date()
				}],
				components: [row],
				ephemeral: true
			});
		}
		
		else if (subcommand === 'end') {
			const session = endSession(userId);
			
			if (!session) {
				return interaction.reply({
					content: '❌ No active session found.',
					ephemeral: true
				});
			}
			
			const duration = Math.floor((Date.now() - session.startTime) / 1000);
			const minutes = Math.floor(duration / 60);
			const seconds = duration % 60;
			
			return interaction.reply({
				embeds: [{
					color: 0x10b981, // green
					title: '✅ Longstring Session Ended',
					fields: [
						{ name: '📊 Total Rolls', value: `${session.rolls.length}`, inline: true },
						{ name: '⏱️ Duration', value: `${minutes}m ${seconds}s`, inline: true },
						{ name: '📝 Raw String', value: session.rawString || 'No input', inline: false },
						{ name: '🔍 Decoded', value: session.rolls.length > 0 ? session.rolls.join(' → ') : 'No rolls', inline: false }
					],
					footer: { text: 'Svarog Tracer • Longstring Summary' },
					timestamp: new Date()
				}],
				ephemeral: true
			});
		}
		
		else if (subcommand === 'status') {
			const stats = getSessionStats(userId);
			
			if (!stats) {
				return interaction.reply({
					content: '❌ No active session. Use `/st-longstring start` to begin!',
					ephemeral: true
				});
			}
			
			const session = getSession(userId);
			
			if (session.mode !== 'longstring') {
				return interaction.reply({
					content: '❌ Current session is not a longstring session. Use `/st-session status` instead.',
					ephemeral: true
				});
			}
			
			const progress = Math.min(session.rolls.length, 6);
			const progressBar = '▰'.repeat(progress) + '▱'.repeat(6 - progress);
			
			const minutes = Math.floor(stats.duration / 60);
			const seconds = stats.duration % 60;
			
			const statusText = stats.isExpired 
				? `⚠️ **EXPIRED** (${session.timerMinutes}min window passed)` 
				: session.hasTimer 
					? '✅ **ACTIVE**' 
					: '✅ **ACTIVE** (No timer)';
			
			return interaction.reply({
				embeds: [{
					color: stats.isExpired ? 0xef4444 : 0x10b981, // red if expired, emerald if active
					title: '📊 Longstring Session Status',
					fields: [
						{ name: '🎯 Status', value: statusText, inline: false},
						{ name: '📝 Progress', value: `\`${progressBar}\` ${session.rolls.length}/6 rolls`, inline: false },
						{ name: '⏱️ Duration', value: `${minutes}m ${seconds}s`, inline: true },
						{ name: '📏 String Length', value: `${session.rawString.length} chars`, inline: true },
						{ name: '📋 Raw Input', value: session.rawString || 'None yet', inline: false },
						{ name: '🔍 Recent Rolls', value: session.rolls.length > 0 ? session.rolls.slice(-8).join(' → ') : 'None yet', inline: false }
					],
					footer: { text: 'Svarog Tracer • Longstring Session' },
					timestamp: new Date()
				}],
				ephemeral: true
			});
		}
	},
};
