import { generateOverrideMap, BANNER_CONFIG } from '../config/banners.js';

const SRS_API_BASE = "https://starrailstation.com/api/v1/warp_fetch/";
const PAIMON_API_BASE = "https://api.paimon.moe/wish";

// Use centralized config
const OVERRIDE_MAP = generateOverrideMap();

// --- WuWa Background Sync ---
let WUWA_CACHE = {
    banners: [],
    lastUpdate: 0
};

// Guard: prevents two concurrent syncs from piling up
let _syncRunning = false;

async function runWuWaSync() {
    // Skip if a previous sync is still in-flight (prevents stacking)
    if (_syncRunning) {
        console.warn('[BG Sync] Previous sync still running — skipping this tick.');
        return;
    }
    _syncRunning = true;

    try {
        console.log('[BG Sync] Fetching fresh WuWa data...');

        // Hard 25s timeout on the entire fetch operation
        // If it hangs longer than this, we abort rather than block the interval
        const b = await Promise.race([
            fetchWuWaLiveBanners(),
            new Promise((_, reject) =>
                setTimeout(() => reject(new Error('WuWa sync timed out after 25s')), 25_000)
            )
        ]);

        if (b && b.length > 0) {
            WUWA_CACHE.banners = b;
            WUWA_CACHE.lastUpdate = Date.now();
            console.log(`[BG Sync] WuWa cache updated: ${b.length} banners.`);
        } else {
            console.warn('[BG Sync] Fetch returned empty — keeping stale cache.');
        }
    } catch (e) {
        console.error('[BG Sync] Sync error (cache kept):', e.message);
    } finally {
        _syncRunning = false;
    }
}

export function startBackgroundSync() {
    console.log('[BG Sync] Starting background synchronization...');

    // Initial fetch (don't await — let the bot finish loading first)
    runWuWaSync();

    // Every 15 minutes — uses setInterval safely because runWuWaSync has its own lock
    setInterval(runWuWaSync, 15 * 60 * 1000);
}


// Helper: Simple fetch with timeout (Node.js version)
async function fetchWithTimeout(url, timeoutMs = 8000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

// =========================================================================
// BANNER FETCHING - Now uses centralized Vercel API
// =========================================================================

const VERCEL_API_URL = process.env.VERCEL_API_URL || 'https://svarog-tracer.vercel.app';

// Fate/Stay Night Manual Config (Synced with Website)
const FATE_CHARACTERS = [
  {
    id: "5001",
    name: "Saber",
    type: "character", 
    image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1014.png",
    game: 'hsr'
  },
  {
    id: "5002",
    name: "Archer", 
    type: "character",
    image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1015.png",
    game: 'hsr'
  }
];

const FATE_LIGHT_CONES = [
  {
    id: "6001",
    name: "A Thankless Coronation",
    type: "light_cone",
    image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_preview/23045.png",
    game: 'hsr'
  },
  {
    id: "6002",
    name: "The Hell Where Ideals Burn",
    type: "light_cone",
    image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_preview/23046.png",
    game: 'hsr'
  }
];

export async function fetchLiveBanners() {
    try {
        console.log('[fetchLiveBanners] Fetching from centralized API...');
        const response = await fetch(`${VERCEL_API_URL}/api/banners`);
        
        if (!response.ok) {
            console.error(`[fetchLiveBanners] API returned ${response.status}`);
            return { hsr: [], genshin: [], wuwa: [] };
        }
        
        const data = await response.json();
        console.log(`[fetchLiveBanners] Success! HSR:${data.hsr.length} Genshin:${data.genshin.length} WuWa:${data.wuwa.length}`);
        
        // --- WuWa Automation (CRITICAL FIX) ---
        // Prefer local bot scraper results over potentially stale Vercel API
        const finalWuWa = (WUWA_CACHE.banners && WUWA_CACHE.banners.length > 0) 
            ? WUWA_CACHE.banners 
            : (data.wuwa || []);

        // Merge Fate Banners into HSR list
        const hsrWithFate = [
            ...(data.hsr || []),
            ...FATE_CHARACTERS,
            ...FATE_LIGHT_CONES
        ];

        // AUTOMATED IMAGE RESOLUTION FOR ALL BANNERS (Parallel & Fast)
        console.log('[fetchLiveBanners] Resolving images in parallel...');
        
        // 1. Fetch HSR Config Once
        const nowTs = Date.now();
        const configRes = await fetchWithTimeout(`https://starrailstation.com/api/v1/warp_config?_t=${nowTs}`, 5000).catch(() => null);
        const configData = (configRes && configRes.ok) ? await configRes.json() : null;
        const srsBanners = configData?.config?.banners || {};

        // 2. Parallel Resolution for all games
        await Promise.all([
            // HSR Resolution
            ...hsrWithFate.map(async (banner) => {
                const override = OVERRIDE_MAP[banner.id];
                if (override?.image) {
                    banner.image = override.image;
                    if (override.name && !banner.name) banner.name = override.name;
                } else if (!banner.image) {
                    const bdata = srsBanners[banner.id];
                    if (bdata && bdata.rateup) {
                        const cid = String(bdata.rateup);
                        const isChar = bdata.type === 1 || bdata.type === 11 || bdata.type === 21;
                        banner.image = isChar 
                            ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/${cid}.png`
                            : `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/light_cone/${cid}.png`;
                    } else if (!banner.id.startsWith('5') && !banner.id.startsWith('6')) {
                        // Safe fallback: Try fetchWarpStats sparingly for any missing current HSR banners
                        try {
                            const stats = await fetchWarpStats(banner.id);
                            if (stats.image) banner.image = stats.image;
                        } catch (e) {}
                    }
                }
            }),
            // Genshin Resolution
            ...(data.genshin || []).map(async (banner) => {
                const override = OVERRIDE_MAP[banner.id];
                if (override?.image) {
                    banner.image = override.image;
                } else if (!banner.image) {
                    const idStr = String(banner.id);
                    if (idStr.startsWith('3')) {
                        const name = banner.name || "";
                        banner.image = `https://paimon.moe/images/characters/${name.toLowerCase().replace(/[\s·•]+/g, '_')}.png`;
                    } else if (idStr.startsWith('4')) {
                        banner.image = `https://paimon.moe/images/banners/Epitome%20Invocation%20${idStr.slice(-2)}.png`;
                    }
                }
            }),
            // WuWa Resolution
            ...(data.wuwa || []).map(async (banner) => {
                const override = OVERRIDE_MAP[banner.id];
                if (override) {
                    if (override.name) banner.name = override.name;
                    if (override.image) banner.image = override.image;
                }
                
                if (!banner.image && banner.name && banner.name !== "Unknown Banner") {
                    const isChar = banner.type === 'character';
                    const nameSlug = banner.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'); // More robust slugification
                    banner.image = `https://wuwatracker.com/_next/image?url=%2Fapi%2F${isChar ? 'character' : 'weapon'}-portraits%2Ffile%2F${nameSlug}-portrait.${isChar ? 'webp' : 'png'}&w=828&q=75`;
                }
            })
        ]);

        return {
            hsr: hsrWithFate,
            genshin: data.genshin || [],
            wuwa: finalWuWa
        };
    } catch (error) {
        console.error('[fetchLiveBanners] Error fetching from API:', error);
        return { hsr: [], genshin: [], wuwa: (WUWA_CACHE.banners || []) };
    }
}

// --- HSR LOGIC ---
export async function fetchHSRActiveBanners() {
    try {
        const nowTs = Date.now();
        // 1. Fetch Config
        const configRes = await fetchWithTimeout(`https://starrailstation.com/api/v1/warp_config?_t=${nowTs}`);
        if (!configRes.ok) return [];
        const configData = await configRes.json();
        
        // 2. Filter Active
        const currentSeconds = nowTs / 1000;
        const gachaList = configData.config?.banners || {};
        const activeCandidates = [];
        
        for (const [bid, bdata] of Object.entries(gachaList)) {
            if (bdata.start_time <= currentSeconds && currentSeconds <= bdata.end_time) {
                if (bdata.rateup) { 
                     activeCandidates.push({ id: bid, charId: String(bdata.rateup) });
                }
            }
        }
        
        if (activeCandidates.length === 0) return [];
        
        // 3. Fetch Metadata (Chars + Light Cones)
        const [charRes, lcRes] = await Promise.all([
             fetchWithTimeout("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/characters.json"),
             fetchWithTimeout("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/light_cones.json")
        ]);
        
        const charMap = charRes.ok ? await charRes.json() : {};
        const lcMap = lcRes.ok ? await lcRes.json() : {};
        
        // 4. Map IDs to Names
        const liveBanners = activeCandidates.map(b => {
             // Check Manual Overrides first (by banner ID or character ID)
             const bannerOverride = OVERRIDE_MAP[b.id];
             const charOverride = OVERRIDE_MAP[b.charId];
             const override = bannerOverride || charOverride;
             
             if (override) {
                 return {
                     id: b.id,
                     name: override.name,
                     type: override.type
                 };
             }
             
             // Check Characters
             if (charMap[b.charId]) {
                 return { 
                     id: b.id, 
                     name: charMap[b.charId].name, 
                     type: 'character',
                     image: `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/${b.charId}.png`
                 };
             }
             
             // Check Light Cones (Force String key)
             if (lcMap[String(b.charId)]) {
                 return { 
                     id: b.id, 
                     name: lcMap[String(b.charId)].name, 
                     type: 'light_cone',
                     image: `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/${b.charId}.png`
                 };
             }
             
             return {
                 id: b.id,
                 name: `Unknown (${b.charId})`,
                 type: 'unknown',
                 image: null
             };
        });

        // 5. Merge Fate Collaboration Banners
        const fateBanners = BANNER_CONFIG.hsr.fateCollaboration.map(b => ({
            id: b.bannerId,
            name: b.name,
            type: b.characterId ? 'character' : 'light_cone'
        }));
        
        return [...liveBanners, ...fateBanners];
        
    } catch (e) {
        console.error("HSR Fetch Error:", e);
        return [];
    }
}

// --- GENSHIN LOGIC ---
export async function fetchActiveGenshinBanners() {
    const banners = [];
    
    // Discovery parameters based on current patch IDs
    const charBase = 93;
    const weaponBase = 92;
    const range = 5; 

    const findBanners = async (base, prefix, type) => {
        const checks = [];
        // Check current and future IDs
        for (let i = base; i < base + 6; i++) {
            const bannerId = `${prefix}${i.toString().padStart(3, '0')}`;
        
            // Skip 300093 (Ineffa) - shares data with 300094 (Columbina/Ineffa dual banner)
            if (bannerId === '300093') continue;
        
            checks.push((async () => {
                try {
                    const res = await fetchWithTimeout(`${PAIMON_API_BASE}?banner=${bannerId}`, 3000);
                    if (res.ok) {
                        const data = await res.json();
                        // Filter by pull count to ensure it's a "known" banner
                        if (data.total && data.total.legendary > 300) {
                            const override = OVERRIDE_MAP[bannerId];
                            let name;
                            if (override) {
                                name = override.name;
                            } else if (type === 'weapon') {
                                name = extractGenshinWeaponNames(data.list) || "Epitome Invocation";
                            } else {
                                name = extractGenshinBannerName(data.list);
                            }
                            return { id: bannerId, name: name || 'Unknown', type: override ? override.type : type };
                        }
                    }
                } catch (e) {
                    console.error(`[fetchActiveGenshinBanners] Error checking ${bannerId}:`, e.message);
                }
                return null;
            })());
        }
        const results = (await Promise.all(checks)).filter(b => b !== null);
        // For weapons, only keep THE LATEST one (highest ID) to avoid duplicates
        if (type === 'weapon' && results.length > 1) {
            return [results.sort((a,b) => parseInt(b.id) - parseInt(a.id))[0]];
        }
        return results;
    };

    const [chars, weapons] = await Promise.all([
        findBanners(charBase, '300', 'character'),
        findBanners(weaponBase, '400', 'weapon')
    ]);

    const all = [...chars, ...weapons];
    all.sort((a, b) => parseInt(b.id) - parseInt(a.id));
    return all;
}

// --- WuWa Scraping ---
export async function fetchWuWaLiveBanners() {
    try {
        const res = await fetchWithTimeout('https://wuwatracker.com/tracker/stats', 5000);
        if (!res.ok) return [];
        const html = await res.text();
        
        const idPattern = /[\\"]+bannerId[\\"]+:\s*(\d{6})/g; 
        const banners = [];
        const seen = new Set();
        let match;
        
        while ((match = idPattern.exec(html)) !== null) {
            const id = match[1];
            if (seen.has(id)) continue;
            seen.add(id);
            
            const isCharacter = id.startsWith('100');
            const isWeapon = id.startsWith('101') || id.startsWith('200');
            if (!isCharacter && !isWeapon) continue;

            const pos = match.index;
            const context = html.substring(pos, pos + 5000);
            
            const rateUpBlock = context.match(/[\\"]+5stars[\\"]+:\s*\[([\s\S]*?)\]/);
            let name = null;
            if (rateUpBlock) {
                const nameMatch = rateUpBlock[1].match(/[\\"]+name[\\"]+:\s*[\\"]+([^\\"]+)[\\"]+/);
                if (nameMatch) name = nameMatch[1];
            }
            
            if (!name || name.includes("Featured") || name.includes("Convene")) {
                const topNameMatch = context.match(/[\\"]+name[\\"]+:\s*[\\"]+([^\\"]+)[\\"]+/);
                name = topNameMatch ? topNameMatch[1] : `Banner ${id}`;
            }

            if (name.toLowerCase().includes('standard')) continue;
            
            const isChar = isCharacter;
            const nameSlug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
            const ext = 'png'; 
            const imgPath = isChar ? 'character-portraits' : 'weapon-portraits';
            const fileName = isChar ? `${nameSlug}-portrait.${ext}` : `${nameSlug}.${ext}`;
            
            banners.push({ 
                id, 
                name, 
                type: isChar ? 'character' : 'weapon',
                image: `https://wuwatracker.com/_next/image?url=%2Fapi%2F${imgPath}%2Ffile%2F${fileName}&w=828&q=75`,
                game: 'wuwa'
            });
        }

        // ULTRA-ROBUST EMERGENCY FALLBACK
        if (!banners.some(b => b.id === '100032') && html.includes('Aemeath')) {
           banners.push({
             id: '100032',
             name: 'Aemeath',
             type: 'character',
             image: `https://wuwatracker.com/_next/image?url=%2Fapi%2Fcharacter-portraits%2Ffile%2Faemeath-portrait.png&w=828&q=75`,
             game: 'wuwa'
           });
        }
        if (!banners.some(b => b.id === '200032') && html.includes('Everbright Polestar')) {
           banners.push({
             id: '200032',
             name: 'Everbright Polestar',
             type: 'weapon',
             image: `https://wuwatracker.com/_next/image?url=%2Fapi%2Fweapon-portraits%2Ffile%2Feverbright-polestar.png&w=828&q=75`,
             game: 'wuwa'
           });
        }
        
        console.log(`[WuWa Scrape] Total banners found: ${banners.length}`);
        
        const charBanners = banners.filter(b => b.type === 'character')
            .sort((a, b) => b.id.localeCompare(a.id))
            .slice(0, 1);
        
        const weaponBanners = banners.filter(b => b.type === 'weapon')
            .sort((a, b) => b.id.localeCompare(a.id))
            .slice(0, 1);
        
        return [...charBanners, ...weaponBanners];
    } catch (e) {
        console.error("WuWa scrape error:", e);
        return [];
    }
}

function extractGenshinBannerName(list) {
    if (!list || list.length === 0) return null;
    
    // Standard 5-star characters
    const standard = ['Diluc', 'Jean', 'Keqing', 'Mona', 'Qiqi', 'Tighnari', 'Dehya'];
    
    // Known 4-stars to filter out case-insensitively
    const fourStarBlocklist = [
        'Fischl', 'Chevreuse', 'Bennett', 'Xiangling', 'Xingqiu', 'Barbara', 
        'Noelle', 'Sucrose', 'Diona', 'Chongyun', 'Razor', 'Beidou', 'Ningguang',
        'Yanfei', 'Rosaria', 'Xinyan', 'Sayu', 'Kujou Sara', 'Thoma', 'Gorou',
        'Yun Jin', 'Kuki Shinobu', 'Heizou', 'Collei', 'Dori', 'Candace', 'Layla',
        'Faruzan', 'Yaoyao', 'Mika', 'Kaveh', 'Kirara', 'Lynette', 'Freminet',
        'Charlotte', 'Gaming', 'Sethos', 'Kachina', 'Ororon', 'Lan Yan','Aino'
    ].map(n => n.toLowerCase());

    // Filter characters
    const characterCandidates = list.filter(item => {
        if (item.type !== 'character') return false;
        
        const nameLower = item.name.toLowerCase();
        
        // 1. Exclude standard 5-stars
        if (standard.some(s => s.toLowerCase() === nameLower)) return false;
        
        // 2. Exclude known 4-stars
        if (fourStarBlocklist.includes(nameLower)) return false;
        
        // 3. Count Heuristic (5-stars usually have 300-40000 pulls globally)
        // Correcting the threshold to capture new 5-stars but skip massive 4-star pools
        return item.count > 300 && item.count < 35000;
    });

    // Sort by count descending (most relevant 5-star)
    characterCandidates.sort((a, b) => b.count - a.count);
    
    if (characterCandidates.length > 0) {
        // Format name (e.g. raiden_shogun -> Raiden Shogun)
        return characterCandidates[0].name.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    }
    
    return null;
}

function extractGenshinWeaponNames(list) {
    if (!list || list.length === 0) return null;
    
    const standardWeapons = [
        'amos_bow', 'skyward_harp', 'skyward_atlas', 'lost_prayer_to_the_sacred_winds',
        'primordial_jade_winged_spear', 'skyward_spine', 'wolfs_gravestone', 'skyward_pride',
        'skyward_blade', 'aquila_favonia'
    ].map(n => n.toLowerCase());

    const weaponCandidates = list.filter(item => {
        if (item.type !== 'weapon') return false;
        const nameLower = item.name.toLowerCase();
        if (standardWeapons.includes(nameLower)) return false;
        
        // Exclude common 4-star weapons often found in weapon banners
        const weapon4StarBlocklist = [
            'mitternachts_waltz', 'mountain-bracing_bolt', 'winters_vigil', 'lithic_blade', 
            'lithic_spear', 'wavebreakers_fin', 'akuoumaru', 'mounns_moon', 'rust',
            'favonius_warbow', 'eye_of_perception', 'the_flute', 'the_bell'
        ];
        if (weapon4StarBlocklist.includes(nameLower)) return false;

        return item.count > 200 && item.count < 35000;
    });

    weaponCandidates.sort((a, b) => b.count - a.count);
    
    if (weaponCandidates.length > 0) {
        // Take top 2 weapons (dual featured)
        return weaponCandidates.slice(0, 2).map(item => 
            item.name.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
        ).join(' / ');
    }
    
    return null;
}

/**
 * Transforms Paimon.moe data to match Svarog format (Ported from warpDataService.js)
 */
function transformGenshinData(data, bannerId) {
    // pityCount.legendary is 0-indexed: index 0 = pity 0 (always 0), index 3 = pity 3.
    // So roll N = index N (NOT index + 1).
    const pityArray = data.pityCount?.legendary || [];
    const countEachPity = data.countEachPity || [];
    const by_rollnum_pulls_5 = {};
    const by_rollnum_chance_5 = {};
    
    let totalPulls = 0;
    pityArray.forEach((count, index) => {
        const roll = index; // pity 3 = index 3
        if (roll === 0) return; // skip pity-0 (always 0)
        by_rollnum_pulls_5[roll] = count;
        totalPulls += count;
    });
    
    // Conditional probability matching Paimon.moe's Chance%:
    // pityCount[N] / countEachPity[N-1] = "of players AT pity N, what % got a 5★?"
    pityArray.forEach((count, index) => {
        const roll = index;
        if (roll === 0) return;
        const playersAtThisPity = countEachPity[index - 1];
        if (playersAtThisPity && playersAtThisPity > 0) {
            by_rollnum_chance_5[roll] = count / playersAtThisPity;
        } else if (totalPulls > 0) {
            by_rollnum_chance_5[roll] = count / totalPulls; // fallback
        }
    });
    
    const { countWin, countLose } = calculateGenshinWinLoss(data.list, bannerId);
    
    return {
        stats: {
            total_pulls_5: totalPulls || data.total?.legendary || 0,
            by_rollnum_pulls_5,
            by_rollnum_chance_5,
            count_win_5: countWin,
            count_lose_5: countLose
        }
    };
}
function calculateGenshinWinLoss(list, bannerId) {
    if (!list || list.length === 0) return { countWin: 0, countLose: 0 };
    
    const standardPool = ['diluc', 'jean', 'keqing', 'mona', 'qiqi', 'tighnari', 'dehya', 'amos_bow', 'skyward_harp', 'skyward_atlas', 'lost_prayer_to_the_sacred_winds', 'primordial_jade_winged_spear', 'skyward_spine', 'wolfs_gravestone', 'skyward_pride', 'skyward_blade', 'aquila_favonia'];
    
    const featuredItems = list.filter(item => 
        (item.type === 'character' || item.type === 'weapon') && 
        !standardPool.includes(item.name) &&
        item.count > 500
    );
    
    const standardItems = list.filter(item => 
        (item.type === 'character' || item.type === 'weapon') && 
        standardPool.includes(item.name)
    );
    
    let totalWins = 0;
    for (const item of featuredItems) {
        totalWins += (item.count || 0) - (item.guaranteed || 0);
    }
    
    let totalLosses = 0;
    for (const item of standardItems) {
        totalLosses += item.count || 0;
    }
    
    return { countWin: totalWins, countLose: totalLosses };
}

// =========================================================================
// 2. LUCKY PEAKS LOGIC
// =========================================================================

export function consolidatePeaks(peaks, minDistance = 10) {
  if (!peaks || peaks.length === 0) return [];
  const sorted = [...peaks].sort((a, b) => a.roll - b.roll);
  const consolidated = [];
  for (const peak of sorted) {
    const lastPeak = consolidated[consolidated.length - 1];
    if (!lastPeak || (peak.roll - lastPeak.roll) >= minDistance) {
      consolidated.push(peak);
    } else {
      if (peak.chance > lastPeak.chance) consolidated[consolidated.length - 1] = peak;
    }
  }
  return consolidated;
}

export function detectLuckyPeaks(pullsData, chanceData, options = {}) {
  const {
    softPityStart = 74,
    softPityEnd = 90,
    topN = 3,
    topNPreSoftPity = 8,
    topNSoftPity = 3,
    minZScore = 0.5
  } = options;

  if (!chanceData || Object.keys(chanceData).length === 0) return [];

  const calculateZScores = (data, start, end) => {
    const values = [];
    for (let i = start; i <= end; i++) values.push(data[i] || 0);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length);
    const zScores = {};
    for (let i = start; i <= end; i++) {
        const value = data[i] || 0;
        zScores[i] = stdDev > 0 ? (value - mean) / stdDev : 0;
    }
    return { zScores };
  };

  const isLocalMax = (data, roll) => {
    const prev = data[roll - 1] || 0;
    const curr = data[roll] || 0;
    const next = data[roll + 1] || 0;
    return curr > prev && curr > next;
  };

  const analyzeSegment = (start, end, topN, zoneName) => {
    const segmentAnalysis = calculateZScores(chanceData, start, end);
    const rolls = [];
    for (let roll = start; roll <= end; roll++) {
      const chance = chanceData[roll] || 0;
      const zScore = segmentAnalysis.zScores[roll] || 0;
      const isPeak = isLocalMax(chanceData, roll);
      const compositeScore = zScore + (isPeak ? 0.5 : 0);
      if (zScore >= minZScore || isPeak) {
        rolls.push({
          roll,
          chance,
          zScore: typeof zScore === 'number' ? zScore.toFixed(2) : zScore,
          isPeak,
          compositeScore,
          zone: zoneName
        });
      }
    }
    rolls.sort((a, b) => b.compositeScore - a.compositeScore);
    return rolls.slice(0, topN);
  };

  const topPreSoftPity = [
      ...analyzeSegment(1, 24, topN, "pre-soft"),
      ...analyzeSegment(25, 48, topN, "pre-soft"),
      ...analyzeSegment(49, Math.min(73, (softPityStart || 74) - 1), topN, "pre-soft")
  ];

  const softPityAnalysis = calculateZScores(chanceData, softPityStart, softPityEnd);
  const softPityRolls = [];
  for (let roll = softPityStart; roll <= softPityEnd; roll++) {
    const chance = chanceData[roll] || 0;
    const zScore = softPityAnalysis.zScores[roll] || 0;
    const isPeak = isLocalMax(chanceData, roll);
    softPityRolls.push({
      roll,
      chance,
      zScore: typeof zScore === 'number' ? zScore.toFixed(2) : zScore,
      isPeak,
      zone: "soft-pity"
    });
  }
  softPityRolls.sort((a, b) => b.chance - a.chance);
  
  const consolidatedPeaks = consolidatePeaks([...topPreSoftPity, ...softPityRolls.slice(0, topNSoftPity)], 10);
  // Return all consolidated peaks, sorted by roll number (matching website behavior)
  return consolidatedPeaks.sort((a, b) => a.roll - b.roll);
}

// =========================================================================
// 3. FETCH WARP STATS (from SRS/Paimon)
// =========================================================================

export async function fetchWarpStats(bannerId) {
  if (!bannerId) throw new Error("Banner ID required");
  
  const idStr = String(bannerId);
  const cacheBuster = Date.now();
  let targetUrl;
  let bannerName = "Unknown Banner";
  
  // DETECT GAME BASED ON ID PATTERN    
  const idLen = idStr.length;
  
  console.log(`[fetchWarpStats] Routing ID: ${bannerId} (Length: ${idLen})`);
  
  // Genshin Banner: 6 digits, starts with 3 (Character) or 4 (Weapon)
  if (idLen === 6 && (idStr.startsWith('3') || idStr.startsWith('4'))) {
      targetUrl = `${PAIMON_API_BASE}?banner=${bannerId}&_t=${cacheBuster}`;
      console.log(`[fetchWarpStats] Game: Genshin -> ${targetUrl}`);
  } 
  // WuWa Banner: 6 digits, starts with 1 (Character) or 2 (Weapon)
  else if (idLen === 6 && (idStr.startsWith('1') || idStr.startsWith('2'))) {
      console.log(`[fetchWarpStats] Game: WuWa -> Resolving metadata for ${bannerId}`);
      
      // 1. Try Cache First (Fastest)
      const cached = WUWA_CACHE.banners.find(b => b.id === idStr);
      let bannerName = cached ? cached.name : `WuWa Banner ${bannerId}`;
      let bannerImage = cached ? cached.image : null;

      // 2. Fetch/Scrape if not in cache or missing image
      const wuwaUrl = `https://wuwatracker.com/tracker/stats/${bannerId}`;
      const response = await fetchWithTimeout(wuwaUrl, 8000);
      if (!response.ok) throw new Error(`WuWa fetch failed: ${response.status}`);
      const html = await response.text();
      
      if (!cached) {
          // Extract banner name from context around the ID
          const idPos = html.indexOf(idStr);
          const context = html.substring(idPos - 500, idPos + 5000);
          
          const names = [...context.matchAll(/[\\"]+name[\\"]+:\s*[\\\"']+([^\\\"']+)[\\\"']+/g)];
          const validName = names.find(m => 
              m[1].length > 2 && 
              !m[1].includes("Featured") && 
              !m[1].includes("next-size-adjust") &&
              !m[1].includes("Standard") &&
              !m[1].includes("Convene")
          );

          if (validName) {
              bannerName = validName[1];
          } else {
              const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
              if (titleMatch) {
                  bannerName = titleMatch[1].split(' - ')[0].trim();
              }
          }
      }

      // 3. Robust Image Resolution
      if (!bannerImage) {
          const isChar = idStr.startsWith('100');
          const nameSlug = bannerName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
          const ext = 'png';
          const imgPath = isChar ? 'character-portraits' : 'weapon-portraits';
          const fileName = isChar ? `${nameSlug}-portrait.${ext}` : `${nameSlug}.${ext}`;
          bannerImage = `https://wuwatracker.com/_next/image?url=%2Fapi%2F${imgPath}%2Ffile%2F${fileName}&w=828&q=75`;
      }
      
      // 4. Extract histogram data from HTML
      const histPattern = /\{\\\"histogram\\\":\{([^}]+)\}[^}]*\\\"label\\\":\\\"5✦ Pulls per Pity\\\"/;
      const histMatch = html.match(histPattern);
      if (!histMatch) throw new Error('Could not parse WuWa histogram');
      
      let histogramContent = histMatch[1].replace(/\\"/g, '"');
      const histogramJson = `{${histogramContent}}`;
      const histogramData = JSON.parse(histogramJson);
      
      // Extract character/weapon data for total count estimation
      const charPattern = /\\\"itemNameHistogram\\\":\{([^}]+)\}/;
      const charMatch = html.match(charPattern);
      let total_pulls_5;
      
      if (charMatch) {
          let charContent = charMatch[1].replace(/\\"/g, '"');
          const charJson = `{${charContent}}`;
          const characterData = JSON.parse(charJson);
          const items = Object.entries(characterData).map(([name, count]) => ({ name, count: parseInt(count, 10) }));
          items.sort((a, b) => b.count - a.count);
          const featured = items[0];
          
          const isWeaponBanner = items.length <= 4;
          total_pulls_5 = isWeaponBanner ? Math.floor(featured.count * 1.3) : featured.count * 2;
      } else {
          total_pulls_5 = Object.values(histogramData).reduce((sum, count) => sum + parseInt(count, 10), 0);
      }
      
      const by_rollnum_pulls_5 = {};
      const by_rollnum_chance_5 = {};
      
      for (const [pity, count] of Object.entries(histogramData)) {
          const roll = parseInt(pity, 10);
          const pullCount = parseInt(count, 10);
          by_rollnum_pulls_5[roll] = pullCount;
          by_rollnum_chance_5[roll] = total_pulls_5 > 0 ? pullCount / total_pulls_5 : 0;
      }
      
      return {
          stats: {
              total_pulls_5,
              by_rollnum_pulls_5,
              by_rollnum_chance_5,
              count_win_5: total_pulls_5,
              count_lose_5: 0
          },
          _isWuWa: true,
          _derivedName: bannerName,
          image: bannerImage
      };
  }
  // HSR Banner (4 or 5 digits)
  else {
      targetUrl = `${SRS_API_BASE}${bannerId}/?_t=${cacheBuster}`;
  }

  
  const response = await fetchWithTimeout(targetUrl);
  if (!response.ok) {
      console.error(`[fetchWarpStats] Error ${response.status} for ${targetUrl}`);
      const err = new Error(`Failed to fetch stats: ${response.status} for ${targetUrl}`);
      err.httpStatus = response.status; // attach status so callers can check
      throw err;
  }
  
  const data = await response.json();
  
  const override = OVERRIDE_MAP[idStr];
  
  // 1. DYNAMIC NAME RESOLUTION
  if (override?.name) {
      data._derivedName = override.name;
  } else if (idLen === 6 && (idStr.startsWith('3') || idStr.startsWith('4'))) {
      // Genshin Auto-Name
      data._derivedName = extractGenshinBannerName(data.list);
  } else if (idLen === 4 || idLen === 5) {
      // HSR Initial Name (Fallback)
      data._derivedName = bannerName || `HSR Banner ${idStr}`; 
  } else if (idStr === '2099') {
      data._derivedName = "Global Stats (All Time)";
  }

  // 2. DYNAMIC IMAGE & DETAIL RESOLUTION
  if (override?.image) {
      data.image = override.image;
  } else if (!data.image) {
      try {
          if (idLen === 6 && idStr.startsWith('3')) {
              // Genshin Character
              const name = data._derivedName || "";
              data.image = `https://paimon.moe/images/characters/${name.toLowerCase().replace(/[\s·•]+/g, '_')}.png`;
          } else if (idLen === 6 && idStr.startsWith('4')) {
              // Genshin Weapon
              data.image = `https://paimon.moe/images/banners/Epitome%20Invocation%20${idStr.slice(-2)}.png`;
          } else if (idLen === 4 || idLen === 5) {
              // HSR Automated Metadata Resolution
              // Check if rateup is already in data (from warp_fetch)
              let cid = data.rateup ? String(data.rateup) : null;
              let isChar = idStr.startsWith('1') || idStr.startsWith('2') || idStr.startsWith('5');

              // If rateup is missing, try slow lookup from config (only if needed)
              if (!cid && !idStr.startsWith('5')) {
                  console.log(`[HSR Auto-Resolve] Fetching config for ID: ${idStr}`);
                  const configRes = await fetchWithTimeout(`https://starrailstation.com/api/v1/warp_config?_t=${Date.now()}`, 5000);
                  if (configRes.ok) {
                      const configData = await configRes.json();
                      const bdata = configData.config?.banners?.[idStr];
                      if (bdata && bdata.rateup) {
                          cid = String(bdata.rateup);
                          isChar = bdata.type === 1 || bdata.type === 11 || bdata.type === 21;
                      }
                  }
              }

              // Apply resolution if we have a character ID
              if (cid) {
                  // Detailed name lookup if generic
                  if (!data._derivedName || data._derivedName.includes("Banner")) {
                      const [charRes, lcRes] = await Promise.all([
                          fetchWithTimeout("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/characters.json", 3000),
                          fetchWithTimeout("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/light_cones.json", 3000)
                      ]);
                      const charM = charRes.ok ? await charRes.json() : {};
                      const lcM = lcRes.ok ? await lcRes.json() : {};
                      data._derivedName = charM[cid]?.name || lcM[cid]?.name || data._derivedName;
                  }

                  data.image = isChar 
                      ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/${cid}.png`
                      : `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/light_cone/${cid}.png`;
                  
                  console.log(`[HSR Auto-Resolve] ✓ ID: ${idStr}, Resolved: ${data._derivedName}, Image: ${data.image}`);
              }
          }
      } catch (e) {
          console.error(`[fetchWarpStats] Auto-resolve failed for ${idStr}:`, e.message);
      }
  }


  // Final Transformation for Genshin
  if (idLen === 6 && (idStr.startsWith('3') || idStr.startsWith('4'))) {
      return transformGenshinData(data, bannerId);
  }
  
  return data;
}


export function generateShortcutString(peaks, softPityStart = 74) {
    if (!peaks || peaks.length === 0) return "---";
    
    // Include ALL peaks up to hard pity (90) to ensure "pity rolls" are shown
    const hardPity = 90;
    const allPeaks = peaks.filter(p => p.roll <= hardPity).sort((a, b) => a.roll - b.roll);
    
    if (allPeaks.length === 0) return "---";
    return allPeaks.map(p => (p.roll % 10).toString()).join(" ");
}
