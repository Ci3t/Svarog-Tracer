/**
 * BANNER CONFIGURATION
 * 
 * This file contains all banner metadata for manual updates in emergencies.
 * Simply update the banner IDs, names, and image URLs here.
 * 
 * Image URL Patterns:
 * - HSR Characters: https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/{id}.png
 * - HSR Light Cones: https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/{id}.png
 * - Genshin Characters: https://paimon.moe/images/characters/{name}.png
 * - Genshin Weapons: https://paimon.moe/images/weapons/{name}.png
 * - WuWa: (Auto-discovered, no manual config needed)
 */

// =========================================================================
// 🚀 BOT CONTROL CENTER - Edit this for new patches!
// =========================================================================
export const BANNER_CONFIG = {
    // 1. HONKAI: STAR RAIL
    hsr: {
        active: {
            characters: ["2103", "2104"],
            lightCones: ["3103", "3104"],
            fate: ["5001", "5002", "6001", "6002"]
        },
        // Manual overrides (Optional: Use only for naming emergencies)
        metadata: {
            // "ID": { name: "Forced Name", characterId: "InternalID" }
            "2103": { name: "Aglaea", characterId: "1402" },
            "2104": { name: "Sunday", characterId: "1313" },
            "3103": { name: "Time Woven Into Gold", lightConeId: "23036" },
            "3104": { name: "A Grounded Ascent", lightConeId: "23034" },
            "5001": { name: "Saber", characterId: "1014" },
            "5002": { name: "Archer", characterId: "1015" },
            "6001": { name: "A Thankless Coronation", lightConeId: "23045" },
            "6002": { name: "The Hell Where Ideals Burn", lightConeId: "23046" }
        }
    },
    
    // 2. GENSHIN IMPACT
    genshin: {
        active: {
            charBannerIds: ["300096"],
            weaponBannerIds: ["400094"],
            forceNames: {
                "300096": "Varka",
                
            }
        },
        standard: ['tighnari', 'dehya', 'diluc', 'jean', 'keqing', 'mona', 'qiqi', 'ororon', 'lanyan']
    },
    
    // 3. WUTHERING WAVES (Fully Automated)
    wuwa: {
        active: {
            charBannerIds: ["100031"],
            weaponBannerIds: ["200031"]
        },
        forceNames: {
            "100031": "Mornye",
            "200031": "Starfield Calibrator"
        }

    }
};


/**
 * Generate OVERRIDE_MAP from config
 * This creates the format expected by botWarpService.js and wcheck.js
 */
/**
 * Generate OVERRIDE_MAP from config
 * This creates the format expected by botWarpService.js and wcheck.js
 */
export function generateOverrideMap() {
    const map = {};
    
    // HSR
    BANNER_CONFIG.hsr.active.characters.forEach(id => {
        const meta = BANNER_CONFIG.hsr.metadata[id];
        map[id] = {
            name: meta?.name || null,
            type: "character",
            image: meta?.characterId ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/${meta.characterId}.png` : null
        };
    });
    
    BANNER_CONFIG.hsr.active.lightCones.forEach(id => {
        const meta = BANNER_CONFIG.hsr.metadata[id];
        map[id] = {
            name: meta?.name || null,
            type: "light_cone",
            image: meta?.lightConeId ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/light_cone/${meta.lightConeId}.png` : null
        };
    });

    BANNER_CONFIG.hsr.active.fate?.forEach(id => {
        const meta = BANNER_CONFIG.hsr.metadata[id];
        map[id] = {
            name: meta?.name || null,
            type: meta?.characterId ? "character" : (meta?.lightConeId ? "light_cone" : "character"),
            image: meta?.characterId 
                ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/${meta.characterId}.png`
                : (meta?.lightConeId ? `https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/light_cone/${meta.lightConeId}.png` : null)
        };
    });
    
    // Genshin
    BANNER_CONFIG.genshin.active.charBannerIds.forEach(id => {
        const name = BANNER_CONFIG.genshin.active.forceNames[id];
        map[id] = {
            name: name || "Character Event Wish",
            type: "character",
            image: name ? `https://paimon.moe/images/characters/${name.split(' / ')[0].toLowerCase().replace(/ /g, '_')}.png` : null
        };
    });
    
    BANNER_CONFIG.genshin.active.weaponBannerIds.forEach(id => {
        const name = BANNER_CONFIG.genshin.active.forceNames[id];
        map[id] = {
            name: name || "Epitome Invocation",
            type: "weapon",
            image: `https://paimon.moe/images/banners/Epitome%20Invocation%20${id.slice(-2)}.png`
        };
    });
    
    // WuWa
    [...BANNER_CONFIG.wuwa.active.charBannerIds, ...BANNER_CONFIG.wuwa.active.weaponBannerIds].forEach(id => {
        const name = BANNER_CONFIG.wuwa.forceNames[id];
        const isChar = BANNER_CONFIG.wuwa.active.charBannerIds.includes(id);
        map[id] = {
            name: name || (isChar ? "Resonator Convene" : "Weapon Convene"),
            type: isChar ? "character" : "weapon",
            image: name ? `https://wuwatracker.com/_next/image?url=%2Fapi%2F${isChar ? 'character' : 'weapon'}-portraits%2Ffile%2F${name.toLowerCase().replace(/ /g, '-')}-portrait.${isChar ? 'webp' : 'png'}&w=828&q=75` : null
        };
    });
    
    return map;
}
