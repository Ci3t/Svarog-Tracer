# Banner Configuration Guide

## Quick Update Instructions

To manually update banners in an emergency, edit **ONE FILE ONLY**:
```
discord-bot/config/banners.js
```

## How to Update

### 1. HSR Character Banner
```javascript
characters: [
    { 
        bannerId: "2XXX",           // Banner ID from /ids command
        name: "Character Name",      // Display name
        characterId: "1XXX",         // Character ID for image
        image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1XXX.png"
    }
]
```

### 2. HSR Light Cone Banner
```javascript
lightCones: [
    { 
        bannerId: "3XXX",           // Banner ID from /ids command
        name: "Light Cone Name",     // Display name
        lightConeId: "23XXX",        // LC ID for image
        image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/23XXX.png"
    }
]
```

### 3. Genshin Character Banner
```javascript
characters: [
    { 
        bannerId: "300XXX",          // Banner ID from Paimon.moe
        name: "Character Name",       // Display name (use " / " for dual banners)
        image: "https://paimon.moe/images/characters/name.png"
    }
]
```

### 4. Genshin Weapon Banner
```javascript
weapons: [
    { 
        bannerId: "400XXX",          // Banner ID from Paimon.moe
        name: "Weapon 1 / Weapon 2", // Display name (dual weapons)
        image: "https://paimon.moe/images/weapons/name.png"
    }
]
```

## After Updating

1. Save the file
2. Restart the bot: `Ctrl+C` then `node index.js`
3. Test with `/wcheck <banner_id>`

## Finding IDs

- **HSR**: Use `/ids` command or check https://starrailstation.com
- **Genshin**: Check https://paimon.moe/wish
- **Character/LC IDs**: Check StarRailRes GitHub or Paimon.moe

## Example: New HSR Patch

```javascript
characters: [
    { 
        bannerId: "2103",
        name: "Sunday",
        characterId: "1310",
        image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1310.png"
    }
],
lightCones: [
    { 
        bannerId: "3103",
        name: "Eternal Calculus",
        lightConeId: "24001",
        image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/24001.png"
    }
]
```

That's it! The bot will automatically use the new configuration.
