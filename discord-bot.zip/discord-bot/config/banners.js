/**
 * BANNER CONFIGURATION
 * 
 * This file contains all banner metadata for manual updates in emergencies.
 * Simply update the banner IDs, names, and image URLs here.
 * 
 * Image URL Patterns:
 * - HSR Characters: https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/{id}.png
 * - HSR Light Cones: https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/{id}.png
 * - Genshin Characters: https://paimon.moe/images/characters/{name}.png
 * - Genshin Weapons: https://paimon.moe/images/weapons/{name}.png
 * - WuWa: (Auto-discovered, no manual config needed)
 */

export const BANNER_CONFIG = {
    // ========================================
    // HONKAI: STAR RAIL
    // ========================================
    hsr: {
        // Current Character Banners
        characters: [
            { 
                bannerId: "2101", 
                name: "Fugue", 
                characterId: "1225",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1225.png"
            },
            { 
                bannerId: "2102", 
                name: "Lingsha", 
                characterId: "1222",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1222.png"
            }
        ],
        
        // Current Light Cone Banners
        lightCones: [
            { 
                bannerId: "3101", 
                name: "Long Road Leads Home", 
                lightConeId: "23035",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/23035.png"
            },
            { 
                bannerId: "3102", 
                name: "Scent Alone Stays True", 
                lightConeId: "23032",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/23032.png"
            }
        ],
        
        // Fate/Stay Night Collaboration (if active)
        fateCollaboration: [
            { 
                bannerId: "5001", 
                name: "Saber", 
                characterId: "1014",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1014.png"
            },
            { 
                bannerId: "5002", 
                name: "Archer", 
                characterId: "1015",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/icon/character/1015.png"
            },
            { 
                bannerId: "6001", 
                name: "A Thankless Coronation", 
                lightConeId: "23045",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/23045.png"
            },
            { 
                bannerId: "6002", 
                name: "The Hell Where Ideals Burn", 
                lightConeId: "23046",
                image: "https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/image/light_cone_portrait/23046.png"
            }
        ]
    },
    
    // ========================================
    // GENSHIN IMPACT
    // ========================================
    genshin: {
        // Current Character Banners (can be dual banners with same ID)
        characters: [
            { 
                bannerId: "300094", 
                name: "Columbina / Ineffa",  // Dual banner - both characters share same ID
                image: "https://paimon.moe/images/characters/columbina.png"
            }
        ],
        
        // Current Weapon Banners (usually dual weapons)
        weapons: [
            { 
                bannerId: "400093", 
                name: "Nocturne's Curtain Call / Fractured Halo",
                image: "https://paimon.moe/images/weapons/nocturnes_curtain_call.png"
            }
        ]
    },
    
    // ========================================
    // WUTHERING WAVES
    // ========================================
    wuwa: {
        // WuWa banners are auto-discovered from wuwatracker.com
        // Add manual overrides here if auto-discovery fails or for custom images
        manualOverrides: [
            // Current banners (update these when new patch releases)
            { 
                bannerId: "100031", 
                name: "Mornye",
                type: "character",
                // Pattern for characters: character-portraits + webp
                image: "https://wuwatracker.com/_next/image?url=%2Fapi%2Fcharacter-portraits%2Ffile%2Fmornye-portrait.webp&w=828&q=75"
            },
            { 
                bannerId: "200031", 
                name: "Starfield Calibrator",
                type: "weapon",
                // Pattern for weapons: weapon-portraits + png
                image: "https://wuwatracker.com/_next/image?url=%2Fapi%2Fweapon-portraits%2Ffile%2Fstarfield-calibrator-portrait.png&w=828&q=75"
            }
        ]
    }
};

/**
 * Generate OVERRIDE_MAP from config
 * This creates the format expected by botWarpService.js and wcheck.js
 */
export function generateOverrideMap() {
    const map = {};
    
    // HSR Characters
    BANNER_CONFIG.hsr.characters.forEach(banner => {
        map[banner.bannerId] = {
            name: banner.name,
            type: "character",
            image: banner.image
        };
    });
    
    // HSR Light Cones
    BANNER_CONFIG.hsr.lightCones.forEach(banner => {
        map[banner.bannerId] = {
            name: banner.name,
            type: "light_cone",
            image: banner.image
        };
    });
    
    // HSR Fate Collaboration
    BANNER_CONFIG.hsr.fateCollaboration.forEach(banner => {
        const type = banner.characterId ? "character" : "light_cone";
        map[banner.bannerId] = {
            name: banner.name,
            type: type,
            image: banner.image
        };
    });
    
    // Genshin Characters
    BANNER_CONFIG.genshin.characters.forEach(banner => {
        map[banner.bannerId] = {
            name: banner.name,
            type: "character",
            image: banner.image
        };
    });
    
    // Genshin Weapons
    BANNER_CONFIG.genshin.weapons.forEach(banner => {
        map[banner.bannerId] = {
            name: banner.name,
            type: "weapon",
            image: banner.image
        };
    });
    
    // WuWa Manual Overrides
    BANNER_CONFIG.wuwa.manualOverrides.forEach(banner => {
        map[banner.bannerId] = {
            name: banner.name,
            type: banner.bannerId.startsWith('1') ? "character" : "weapon",
            image: banner.image
        };
    });
    
    return map;
}
