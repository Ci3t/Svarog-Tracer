import fetch from 'node-fetch';

async function testGenshin() {
    const id = '400093';
    const baseUrl = "https://api.paimon.moe/wish";
    
    console.log('Testing WITHOUT _t:');
    const res1 = await fetch(`${baseUrl}?banner=${id}`);
    console.log('Status:', res1.status);
    if (res1.ok) {
        const data = await res1.json();
        console.log('Got data, legendary count:', data.total?.legendary);
    }
    
    console.log('\nTesting WITH _t:');
    const res2 = await fetch(`${baseUrl}?banner=${id}&_t=${Math.floor(Date.now()/300000)}`);
    console.log('Status:', res2.status);
}

testGenshin();
