import fetch from 'node-fetch';

async function test() {
    // Test HSR Global
    try {
        console.log('--- HSR 2099 ---');
        const r1 = await fetch('https://starrailstation.com/api/v1/warp_fetch/2099');
        const d1 = await r1.json();
        console.log('Keys:', Object.keys(d1));
        // Check for name
        // Usually SRS doesn't return the name in the stats object, we might have to infer it or fetch a list
    } catch(e) { console.log(e.message) }

    // Test Genshin
    try {
        console.log('--- Genshin 300094 ---');
        const r2 = await fetch('https://api.paimon.moe/wish?banner=300094');
        console.log('Status:', r2.status);
        if (r2.ok) {
            const d2 = await r2.json();
            console.log('Keys:', Object.keys(d2));
            if (d2.title) console.log('Title:', d2.title); // Paimon might return name
        }
    } catch(e) { console.log(e.message) }
}

test();
