import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { createSession, getSession, endSession, getSessionStats } from '../utils/sessionManager.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-session')
		.setDescription('Manage your live prediction session')
		.addSubcommand(subcommand =>
			subcommand
				.setName('start')
				.setDescription('Start a new live prediction session')
				.addStringOption(option =>
					option.setName('timer')
						.setDescription('Session timer (default: 5min)')
						.setRequired(false)
						.addChoices(
							{ name: '5 minutes (default)', value: '5' },
							{ name: 'No timer (manual end only)', value: 'none' }
						)))
		.addSubcommand(subcommand =>
			subcommand
				.setName('end')
				.setDescription('End your current session'))
		.addSubcommand(subcommand =>
			subcommand
				.setName('status')
				.setDescription('Check current session status')),
	
	async execute(interaction) {
		const subcommand = interaction.options.getSubcommand();
		const userId = interaction.user.id;
		
		if (subcommand === 'start') {
			// Check if user already has an active session
			const existingSession = getSession(userId);
			if (existingSession) {
				return interaction.reply({
					content: '⚠️ You already have an active session! Use `/st-session end` to finish it first.',
					ephemeral: true
				});
			}
			
			// Get timer option
			const timerOption = interaction.options.getString('timer') || '5';
			const hasTimer = timerOption !== 'none';
			const timerMinutes = hasTimer ? parseInt(timerOption) : 0;
			
			// Create new session with timer option
			createSession(userId, { 
				hasTimer, 
				timerMinutes, 
				mode: 'live',
				user: interaction.user
			});
			
			const timerText = hasTimer 
				? `Session expires after ${timerMinutes} minutes.`
				: 'No timer - session continues until you end it manually.';
			
			const row = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setCustomId('set_response_channel')
						.setLabel('📱 Channel Output')
						.setStyle(ButtonStyle.Success)
						.setDisabled(true), // Default choice
					new ButtonBuilder()
						.setCustomId('set_response_dm')
						.setLabel('📬 DM Output')
						.setStyle(ButtonStyle.Secondary)
				);
			
			return interaction.reply({
				embeds: [{
					color: 0xfbbf24, // amber
					title: '🎯 Live Prediction Session Started',
					description: 'Type your 2-digit rolls in this channel (e.g., `42`, `32`, `41`)\n\n' +
					             '**Predictions start after roll #6**\n' +
					             timerText,
					fields: [
						{ name: '📝 Progress', value: '`▱▱▱▱▱▱` 0/6 rolls', inline: false },
						{ name: '⏱️ Timer', value: hasTimer ? `${timerMinutes} minutes` : 'Disabled', inline: true },
						{ name: '🔒 Privacy', value: 'Ephemeral (only you see this)', inline: true }
					],
					footer: { text: 'Svarog Tracer • Live Prediction' },
					timestamp: new Date()
				}],
				components: [row],
				ephemeral: true
			});
		}
		
		else if (subcommand === 'end') {
			const session = endSession(userId);
			
			if (!session) {
				return interaction.reply({
					content: '❌ No active session found.',
					ephemeral: true
				});
			}
			
			const duration = Math.floor((Date.now() - session.startTime) / 1000);
			const minutes = Math.floor(duration / 60);
			const seconds = duration % 60;
			
			return interaction.reply({
				embeds: [{
					color: 0x10b981, // green
					title: '✅ Session Ended',
					fields: [
						{ name: '📊 Total Rolls', value: `${session.rolls.length}`, inline: true },
						{ name: '⏱️ Duration', value: `${minutes}m ${seconds}s`, inline: true },
						{ name: '📝 Sequence', value: session.rolls.length > 0 ? session.rolls.join(' → ') : 'No rolls recorded', inline: false }
					],
					footer: { text: 'Svarog Tracer • Session Summary' },
					timestamp: new Date()
				}],
				ephemeral: true
			});
		}
		
		else if (subcommand === 'status') {
			const stats = getSessionStats(userId);
			
			if (!stats) {
				return interaction.reply({
					content: '❌ No active session. Use `/st-session start` to begin!',
					ephemeral: true
				});
			}
			
			const session = getSession(userId);
			const progress = Math.min(session.rolls.length, 6);
			const progressBar = '▰'.repeat(progress) + '▱'.repeat(6 - progress);
			
			const minutes = Math.floor(stats.duration / 60);
			const seconds = stats.duration % 60;
			const timeSinceRoll = stats.timeSinceLastRoll;
			
			let statusText = stats.isExpired ? '⚠️ **EXPIRED** (5min window passed)' : '✅ **ACTIVE**';
			
			return interaction.reply({
				embeds: [{
					color: stats.isExpired ? 0xef4444 : 0xfbbf24, // red if expired, amber if active
					title: '📊 Session Status',
					fields: [
						{ name: '🎯 Status', value: statusText, inline: false},
						{ name: '📝 Progress', value: `\`${progressBar}\` ${session.rolls.length}/6 rolls`, inline: false },
						{ name: '⏱️ Duration', value: `${minutes}m ${seconds}s`, inline: true },
						{ name: '🕐 Last Roll', value: `${timeSinceRoll}s ago`, inline: true },
						{ name: '📋 Recent Rolls', value: session.rolls.length > 0 ? session.rolls.slice(-8).join(' → ') : 'None yet', inline: false }
					],
					footer: { text: 'Svarog Tracer • Live Session' },
					timestamp: new Date()
				}],
				ephemeral: true
			});
		}
	},
};
