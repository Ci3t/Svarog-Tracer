import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import crypto from 'crypto';

const API_URL = process.env.VERCEL_API_URL || 'https://ci3t.github.io/Svarog-Tracer';
const API_KEY = process.env.ADMIN_API_KEY || crypto.randomBytes(32).toString('hex');

export default {
	data: new SlashCommandBuilder()
		.setName('st-admin')
		.setDescription('Admin commands for Svarog Tracer')
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
		.addSubcommand(subcommand =>
			subcommand
				.setName('video-add')
				.setDescription('Add a new video tutorial to the guides')
				.addStringOption(option =>
					option.setName('creator')
						.setDescription('Creator ID (bbp or ciet)')
						.setRequired(true)
						.addChoices(
							{ name: 'BigBoiPinoy (BBP)', value: 'bbp' },
							{ name: 'Ciet', value: 'ciet' }
						))
				.addStringOption(option =>
					option.setName('video-id')
						.setDescription('YouTube video ID (e.g., QrqPENtcFus)')
						.setRequired(true))
				.addStringOption(option =>
					option.setName('title')
						.setDescription('Video title')
						.setRequired(true))
				.addStringOption(option =>
					option.setName('description')
						.setDescription('Short description of the video')
						.setRequired(false))
				.addBooleanOption(option =>
					option.setName('featured')
						.setDescription('Mark as featured video')
						.setRequired(false)))
		.addSubcommand(subcommand =>
			subcommand
				.setName('video-delete')
				.setDescription('Delete a video from the guides')
				.addStringOption(option =>
					option.setName('creator')
						.setDescription('Creator ID (bbp or ciet)')
						.setRequired(true)
						.addChoices(
							{ name: 'BigBoiPinoy (BBP)', value: 'bbp' },
							{ name: 'Ciet', value: 'ciet' }
						))
				.addStringOption(option =>
					option.setName('video-id')
						.setDescription('YouTube video ID to delete')
						.setRequired(true)))
		.addSubcommand(subcommand =>
			subcommand
				.setName('video-modify')
				.setDescription('Modify an existing video')
				.addStringOption(option =>
					option.setName('creator')
						.setDescription('Creator ID (bbp or ciet)')
						.setRequired(true)
						.addChoices(
							{ name: 'BigBoiPinoy (BBP)', value: 'bbp' },
							{ name: 'Ciet', value: 'ciet' }
						))
				.addStringOption(option =>
					option.setName('old-video-id')
						.setDescription('Current YouTube video ID')
						.setRequired(true))
				.addStringOption(option =>
					option.setName('new-video-id')
						.setDescription('New YouTube video ID (optional)')
						.setRequired(false))
				.addStringOption(option =>
					option.setName('title')
						.setDescription('New title (optional)')
						.setRequired(false))
				.addStringOption(option =>
					option.setName('description')
						.setDescription('New description (optional)')
						.setRequired(false))
				.addBooleanOption(option =>
					option.setName('featured')
						.setDescription('Mark as featured (optional)')
						.setRequired(false))),
	
	async execute(interaction) {
		// Security Check - USER ID LOCK
		if (interaction.user.id !== '110890964364627968') {
			return interaction.reply({ content: '⛔ **Access Denied**: This command is restricted to the developer.', ephemeral: true });
		}

		const subcommand = interaction.options.getSubcommand();
		
		if (subcommand === 'video-add') {
			await interaction.deferReply({ ephemeral: true });
			
			const creatorId = interaction.options.getString('creator');
			const videoId = interaction.options.getString('video-id');
			const title = interaction.options.getString('title');
			const description = interaction.options.getString('description') || '';
			const featured = interaction.options.getBoolean('featured') || false;
			
			try {
				const response = await fetch(`${API_URL}/api/guides`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
						'x-api-key': API_KEY
					},
					body: JSON.stringify({
						creatorId,
						video: {
							id: videoId,
							title,
							description,
							featured
						}
					})
				});
				
				const data = await response.json();
				
				if (!response.ok) {
					throw new Error(data.error || `HTTP ${response.status}`);
				}
				
				return interaction.editReply({
					embeds: [{
						color: 0x10b981, // green
						title: '✅ Video Added Successfully',
						description: data.message,
						fields: [
							{ name: 'Video ID', value: videoId, inline: true },
							{ name: 'Creator', value: creatorId.toUpperCase(), inline: true },
							{ name: 'Featured', value: featured ? 'Yes' : 'No', inline: true },
							{ name: 'Title', value: title, inline: false },
							{ name: 'Watch', value: `[Open on YouTube](https://www.youtube.com/watch?v=${videoId})`, inline: false }
						],
						footer: { text: 'Bot & Website will auto-update within 60 seconds' },
						timestamp: new Date()
					}]
				});
			} catch (error) {
				console.error('[Admin] Video add error:', error);
				return interaction.editReply({
					embeds: [{
						color: 0xef4444, // red
						title: '❌ Failed to Add Video',
						description: `Error: ${error.message}`,
						fields: [
							{ name: 'Troubleshooting', value: '• Check if the API is deployed\n• Verify ADMIN_API_KEY environment variable\n• Ensure Vercel Blob is configured' }
						]
					}]
				});
			}
		}
		
		if (subcommand === 'video-delete') {
			await interaction.deferReply({ ephemeral: true });
			
			const creatorId = interaction.options.getString('creator');
			const videoId = interaction.options.getString('video-id');
			
			try {
				const response = await fetch(`${API_URL}/api/guides`, {
					method: 'DELETE',
					headers: {
						'Content-Type': 'application/json',
						'x-api-key': API_KEY
					},
					body: JSON.stringify({ creatorId, videoId })
				});
				
				const data = await response.json();
				
				if (!response.ok) {
					throw new Error(data.error || `HTTP ${response.status}`);
				}
				
				return interaction.editReply({
					embeds: [{
						color: 0xef4444, // red
						title: '🗑️ Video Deleted',
						description: data.message,
						footer: { text: 'Changes applied to Bot & Website' },
						timestamp: new Date()
					}]
				});
			} catch (error) {
				console.error('[Admin] Video delete error:', error);
				return interaction.editReply({
					embeds: [{
						color: 0xef4444,
						title: '❌ Failed to Delete Video',
						description: `Error: ${error.message}`
					}]
				});
			}
		}
		
		if (subcommand === 'video-modify') {
			await interaction.deferReply({ ephemeral: true });
			
			const creatorId = interaction.options.getString('creator');
			const oldVideoId = interaction.options.getString('old-video-id');
			const newVideoId = interaction.options.getString('new-video-id');
			const title = interaction.options.getString('title');
			const description = interaction.options.getString('description');
			const featured = interaction.options.getBoolean('featured');
			
			const updates = {};
			if (newVideoId) updates.id = newVideoId;
			if (title) updates.title = title;
			if (description) updates.description = description;
			if (featured !== null) updates.featured = featured;
			
			if (Object.keys(updates).length === 0) {
				return interaction.editReply({
					embeds: [{
						color: 0xfbbf24, // amber
						title: '⚠️ No Changes',
						description: 'You must specify at least one field to modify.'
					}]
				});
			}
			
			try {
				const response = await fetch(`${API_URL}/api/guides`, {
					method: 'PATCH',
					headers: {
						'Content-Type': 'application/json',
						'x-api-key': API_KEY
					},
					body: JSON.stringify({ creatorId, videoId: oldVideoId, updates })
				});
				
				const data = await response.json();
				
				if (!response.ok) {
					throw new Error(data.error || `HTTP ${response.status}`);
				}
				
				const fields = [];
				if (newVideoId) fields.push({ name: 'New Video ID', value: newVideoId, inline: true });
				if (title) fields.push({ name: 'New Title', value: title, inline: false });
				if (description) fields.push({ name: 'New Description', value: description, inline: false });
				if (featured !== null) fields.push({ name: 'Featured', value: featured ? 'Yes' : 'No', inline: true });
				
				return interaction.editReply({
					embeds: [{
						color: 0x10b981, // green
						title: '✏️ Video Modified',
						description: data.message,
						fields: fields,
						footer: { text: 'Changes applied to Bot & Website' },
						timestamp: new Date()
					}]
				});
			} catch (error) {
				console.error('[Admin] Video modify error:', error);
				return interaction.editReply({
					embeds: [{
						color: 0xef4444,
						title: '❌ Failed to Modify Video',
						description: `Error: ${error.message}`
					}]
				});
			}
		}
	},
};
