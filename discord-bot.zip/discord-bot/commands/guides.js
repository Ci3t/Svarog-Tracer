import { SlashCommandBuilder } from 'discord.js';

const API_URL = process.env.VERCEL_API_URL || 'https://ci3t.github.io/Svarog-Tracer';
const WEBSITE_URL = 'https://ci3t.github.io/Svarog-Tracer';
const GUIDES_URL = `${WEBSITE_URL}/guides`;

const WRITTEN_GUIDES = [
    { title: '🔴 Live Mode Guide', desc: 'Real-time pattern detection, prediction strategies, and session management.', link: GUIDES_URL },
    { title: '🧪 Long String Lab Guide', desc: 'Offline analysis, backtesting strategies, and pattern validation.', link: GUIDES_URL },
    { title: '🌊 Kiyo Mode Guide', desc: 'Wave analysis, column-based prediction, and flip pattern detection.', link: GUIDES_URL },
    { title: '📊 Warp Analyzer Guide', desc: 'Community pull data analysis, lucky peaks, and shortcut strings.', link: GUIDES_URL }
];

async function fetchGuides() {
	try {
		const response = await fetch(`${API_URL}/api/guides`);
		if (response.ok) {
			return await response.json();
		}
	} catch (error) {
		console.error('[Guides] Failed to fetch from API:', error);
	}
	return null;
}

export default {
	data: new SlashCommandBuilder()
		.setName('st-guides')
		.setDescription('Access Svarog Tracer tutorials and documentation')
		.addSubcommand(subcommand =>
			subcommand
				.setName('written')
				.setDescription('Get links to written documentation on the website'))
		.addSubcommand(subcommand =>
			subcommand
				.setName('video')
				.setDescription('Get video tutorials from the community creators')),
	
	async execute(interaction) {
		const subcommand = interaction.options.getSubcommand();
		
		if (subcommand === 'written') {
			const fields = WRITTEN_GUIDES.map(g => ({
				name: g.title,
				value: `${g.desc}\n[Read Guide](${g.link})`,
				inline: false
			}));

			return interaction.reply({
				embeds: [{
					color: 0x8b5cf6, // violet
					title: '📚 Svarog Tracer Written Guides',
					description: 'Detailed documentation for every mode available on the website.',
					fields: fields,
					footer: { text: 'Svarog Tracer • Education Module' },
					timestamp: new Date()
				}],
				ephemeral: true
			});
		}
		
		if (subcommand === 'video') {
			await interaction.deferReply({ ephemeral: true });
			
			const guidesData = await fetchGuides();
			
			if (!guidesData || !guidesData.creators) {
				return interaction.editReply({
					embeds: [{
						color: 0xef4444,
						title: '❌ Failed to Load Videos',
						description: 'Could not fetch guides from the API. Please try again later.'
					}]
				});
			}
			
			const embeds = guidesData.creators.map(creator => {
				const videoLinks = creator.videos.map(v => 
					`• [${v.title}](https://www.youtube.com/watch?v=${v.id})`
				).join('\n');

				return {
					color: 0xef4444, // youtube red
					title: `📺 ${creator.name}`,
					url: creator.channelUrl,
					description: `*${creator.description}*\n\n**Featured Tutorials:**\n${videoLinks}`,
					footer: { text: 'Svarog Tracer • Community Content' }
				};
			});

			return interaction.editReply({
				embeds: embeds
			});
		}
	},
};
