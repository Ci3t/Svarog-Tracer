import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { fetchLiveBanners } from '../utils/botWarpService.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-ids')
		.setDescription('List current Warp/Banner IDs for /st-check'),
	async execute(interaction) {
        await interaction.deferReply();
        
        let hsrText = 'Fetching...';
        let genshinText = 'Fetching...';
        let wuwaText = 'Fetching...';

        try {
            const { hsr, genshin, wuwa } = await fetchLiveBanners();
            
            // Format HSR
            if (hsr.length > 0) {
                const chars = hsr.filter(b => b.type === 'character' || b.type === 'unknown');
                const lcs = hsr.filter(b => b.type === 'light_cone');
                
                let text = "";
                if (chars.length > 0) {
                    text += "👤 **Characters**\n" + chars.map(b => `${b.name}: \`${b.id}\``).join('\n') + "\n\n";
                }
                if (lcs.length > 0) {
                    text += "🗡️ **Light Cones**\n" + lcs.map(b => `${b.name}: \`${b.id}\``).join('\n') + "\n\n";
                }
                hsrText = text.trim();
            } else {
                hsrText = '`2099` (Global Stats)\n*(No active banner found)*';
            }
            
            // Format Genshin
            if (genshin.length > 0) {
                const chars = genshin.filter(b => b.type === 'character');
                const weapons = genshin.filter(b => b.type === 'weapon');
                
                let text = "";
                if (chars.length > 0) {
                    text += "🌟 **5-Star Banners**\n" + chars.map(b => `**${b.name}**: \`${b.id}\``).join('\n') + "\n\n";
                }
                if (weapons.length > 0) {
                    text += "⚔️ **Weapon Banners**\n" + weapons.map(b => `**${b.name}**: \`${b.id}\``).join('\n') + "\n\n";
                }
                genshinText = text.trim();
            } else {
                genshinText = '*(No active banner found)*';
            }

            // WuWa
            if (wuwa && wuwa.length > 0) {
                const chars = wuwa.filter(b => b.type === 'character');
                const weapons = wuwa.filter(b => b.type === 'weapon');
                
                let text = '';
                if (chars.length > 0) {
                    text += "👤 **Resonators**\n" + chars.map(b => `${b.name}: \`${b.id}\``).join('\n') + "\n\n";
                }
                if (weapons.length > 0) {
                    text += "⚔️ **Weapons**\n" + weapons.map(b => `${b.name}: \`${b.id}\``).join('\n') + "\n\n";
                }
                wuwaText = text.trim();
            } else {
                wuwaText = '`1` (Standard)\n*Check [WuWa Tracker](https://wuwatracker.com/) for Event IDs*';
            }
            
        } catch (e) {
            console.error(e);
            hsrText = 'Error fetching IDs';
            genshinText = 'Error fetching IDs';
            wuwaText = 'Error fetching IDs';
        }

        const embed = new EmbedBuilder()
            .setColor(0x3b82f6)
            .setTitle('🆔 Active Banner IDs')
            .setDescription('Use these IDs with `/wcheck <id>`')
            .addFields(
                { 
                    name: 'Honkai: Star Rail', 
                    value: hsrText + '\n*(Or use `2099` for Global)*', 
                    inline: false 
                },
                { 
                    name: 'Genshin Impact', 
                    value: genshinText, 
                    inline: false 
                },
                { 
                    name: 'Wuthering Waves', 
                    value: wuwaText, 
                    inline: false 
                }
            )
            .setFooter({ text: 'Svarog Tracer • ID Helper' });

		await interaction.editReply({ embeds: [embed] });
	},
};
