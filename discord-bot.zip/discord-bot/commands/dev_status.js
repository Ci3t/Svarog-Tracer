import { SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-status')
		.setDescription('Advanced bot diagnostic information'),
	async execute(interaction) {
		if (interaction.user.id !== '110890964364627968') return interaction.reply({ content: '⛔ Dev only.', ephemeral: true });

		const sent = await interaction.reply({ content: 'Fetching status...', fetchReply: true, ephemeral: true });
        
        const uptime = process.uptime();
        const hrs = Math.floor(uptime / 3600);
        const mins = Math.floor((uptime % 3600) / 60);
        
		await interaction.reply({ 
            content: `🤖 **Svarog Tracer Diagnostic**\n` +
                     `- Uptime: \`${hrs}h ${mins}m\`\n` +
                     `- Servers: \`${interaction.client.guilds.cache.size}\`\n` +
                     `- Memory: \`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\``, 
            ephemeral: true 
        });
	},
};
