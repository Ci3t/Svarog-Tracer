import { SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-caesar')
		.setDescription('Convert any line format to 4x (standard format)')
		.addStringOption(option =>
			option.setName('value')
				.setDescription('Value to convert (e.g., 32, 23, 11)')
				.setRequired(true)),
	
	async execute(interaction) {
		const input = interaction.options.getString('value');
		
		// Validate it's a 2-digit number
		if (!/^\d{2}$/.test(input)) {
			return interaction.reply({
				content: `❌ Invalid input: \`${input}\`. Must be a 2-digit value (e.g., 32, 23, 11).`,
				ephemeral: true
			});
		}
		
		const firstDigit = parseInt(input[0]);
		const secondDigit = parseInt(input[1]);
		
		// Validate digits are 1-4
		if (firstDigit < 1 || firstDigit > 4 || secondDigit < 1 || secondDigit > 4) {
			return interaction.reply({
				content: `❌ Both digits must be between 1 and 4.`,
				ephemeral: true
			});
		}
		
		// Calculate shift amount to make first digit = 4
		const currentLine = firstDigit;
		const shift = (4 - currentLine + 4) % 4;
		
		// Apply shift to second digit
		const z = secondDigit - 1; // Convert to 0-3
		const s = (z + shift) % 4; // Apply shift
		const newSecondDigit = s + 1; // Convert back to 1-4
		
		// Convert to 4x
		const result = '4' + newSecondDigit;
		
		
		return interaction.reply({
			embeds: [{
				color: 0x8b5cf6, // violet
				title: '🔢 Caesar Conversion',
				description: `**Input:** ${input}\n**Output:** **${result}** (4x format)`,
				footer: { text: `Line ${currentLine} → Line 4` }
			}],
			ephemeral: true
		});
	},
};
