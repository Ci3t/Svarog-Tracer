import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('banners')
		.setDescription('View current live banners'),
	async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(0x9333ea)
            .setTitle('📅 Live Gacha Banners')
            .setDescription('View the interactive **Live Banner Tracker** on Svarog Tracer.')
            .addFields(
                { name: 'Honkai: Star Rail', value: '[View HSR Banners](https://ci3t.github.io/Svarog-Tracer/)', inline: true },
                { name: 'Genshin Impact', value: '[View Genshin Banners](https://ci3t.github.io/Svarog-Tracer/)', inline: true },
                { name: 'Wuthering Waves', value: '[View WuWa Banners](https://ci3t.github.io/Svarog-Tracer/)', inline: true },
            )
            .setImage('https://ci3t.github.io/Svarog-Tracer/og-image.png') // Updated to match base URL
            .setFooter({ text: 'Svarog Tracer • Live Tracking' });

		await interaction.reply({ embeds: [embed] });
	},
};
