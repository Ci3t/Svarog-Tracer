import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { predictWithPairs } from '../../src/utils/pairTransitionPredictor.js';

export default {
	data: new SlashCommandBuilder()
		.setName('analyze')
		.setDescription('Analyze a relic roll history string')
		.addStringOption(option =>
			option.setName('string')
				.setDescription('The history string (e.g., 4142434144)')
				.setRequired(true)),
	async execute(interaction) {
		const inputString = interaction.options.getString('string');
        const cleanString = inputString.replace(/[^0-9]/g, ''); // Basic cleaning
        
        // Convert string only if it matches expected format (2-digit pairs)
        // If user sends "1234", assume they mean indices 1,2,3,4 -> map to 41,42,43,44?
        // Let's support standard 41424344 format for now.
        
        if (cleanString.length % 2 !== 0) {
             return interaction.reply({ content: '❌ Invalid string length! Must be pairs of digits (e.g. 414243...)', ephemeral: true });
        }
        
        const rolls = [];
        for (let i = 0; i < cleanString.length; i += 2) {
            rolls.push(cleanString.substring(i, i + 2));
        }
        
        if (rolls.length < 6) {
            return interaction.reply({ content: `⚠️ **Insufficient Data**: You entered ${rolls.length} rolls. I need at least **6** to detect patterns.`, ephemeral: true });
        }

        const result = predictWithPairs(rolls);
        
        // Color based on confidence
        let color = 0x9333ea; // Purple
        if (result.confidence >= 80) color = 0x22c55e; // Green
        else if (result.confidence >= 60) color = 0xf59e0b; // Amber
        else if (result.confidence < 40) color = 0xef4444; // Red

        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle('🔮 Relic Prediction Analysis')
            .setDescription(`**Input:** \`${cleanString}\`\n**Last Roll:** ${result.lastRoll || 'N/A'}`)
            .addFields(
                { name: 'Target (Next)', value: `**${result.prediction || 'Unknown'}**`, inline: true },
                { name: 'Confidence', value: `${Math.round(result.confidence)}%`, inline: true },
                { name: 'Alternative', value: `${result.alt || 'None'}`, inline: true },
                { name: 'Method', value: `\`${result.method}\``, inline: true },
                { name: 'Logic', value: result.isWaveWarning ? '⚠️ **Wave Flip Warning** detected!' : 'Standard Pattern Follow', inline: false }
            )
            .setFooter({ text: 'Svarog Tracer • Beast Mode v4.0' })
            .setTimestamp();

		await interaction.reply({ embeds: [embed] });
	},
};
