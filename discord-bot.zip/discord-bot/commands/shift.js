import { SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-shift')
		.setDescription('Translate 4x predictions to your current line format')
		.addIntegerOption(option =>
			option.setName('line')
				.setDescription('Your current line (1-4)')
				.setRequired(true)
				.setMinValue(1)
				.setMaxValue(4))
		.addStringOption(option =>
			option.setName('pred1')
				.setDescription('First prediction (e.g., 42)')
				.setRequired(true))
		.addStringOption(option =>
			option.setName('pred2')
				.setDescription('Second prediction (e.g., 43)')
				.setRequired(false)),
	
	async execute(interaction) {
		const line = interaction.options.getInteger('line');
		const pred1 = interaction.options.getString('pred1');
		const pred2 = interaction.options.getString('pred2');
		
		// Validate predictions are 4x format
		const validRolls = ['41', '42', '43', '44'];
		if (!validRolls.includes(pred1)) {
			return interaction.reply({
				content: `❌ Invalid prediction: \`${pred1}\`. Must be one of: 41, 42, 43, 44`,
				ephemeral: true
			});
		}
		
		if (pred2 && !validRolls.includes(pred2)) {
			return interaction.reply({
				content: `❌ Invalid prediction: \`${pred2}\`. Must be one of: 41, 42, 43, 44`,
				ephemeral: true
			});
		}
		
		// Reverse Caesar shift: 4x → Line format
		// Calculate shift amount (reverse of forward shift)
		const shift = (line - 4 + 4) % 4;
		
		// Convert predictions
		function translateToLine(pred) {
			const secondDigit = parseInt(pred[1]); // Get second digit (1, 2, 3, or 4)
			
			// Apply reverse shift
			const z = secondDigit - 1; // Convert to 0-3
			const s = (z + shift) % 4; // Apply shift
			const newSecondDigit = s + 1; // Convert back to 1-4
			
			return line.toString() + newSecondDigit.toString();
		}
		
		const translated1 = translateToLine(pred1);
		const translated2 = pred2 ? translateToLine(pred2) : null;
		
		// Build response
		let response = `📋 **Translated to Line ${line}**\n\n`;
		response += `${pred1} → **${translated1 || 'Out of range'}**\n`;
		if (pred2) {
			response += `${pred2} → **${translated2 || 'Out of range'}**`;
		}
		
		return interaction.reply({
			embeds: [{
				color: 0x06b6d4, // cyan
				title: '🔄 Line Translation',
				description: response,
				footer: { text: `Line 4 → Line ${line}` }
			}],
			ephemeral: true
		});
	},
};
