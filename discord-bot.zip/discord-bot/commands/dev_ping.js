import { SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('st-ping')
		.setDescription('Check bot latency and status'),
	async execute(interaction) {
		if (interaction.user.id !== '110890964364627968') return interaction.reply({ content: '⛔ Dev only.', ephemeral: true });
		
		await interaction.reply({ content: '🏓 Pong! (Dev Mode)', ephemeral: true });
	},
};
