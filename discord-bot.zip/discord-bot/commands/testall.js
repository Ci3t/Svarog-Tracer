import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { fetchLiveBanners, fetchWarpStats, detectLuckyPeaks, generateShortcutString } from '../utils/botWarpService.js';
import { generateOverrideMap } from '../config/banners.js';

// Generate OVERRIDE_MAP from centralized config
const OVERRIDE_MAP = generateOverrideMap();

export default {
	data: new SlashCommandBuilder()
		.setName('st-testall')
		.setDescription('Post all active banners analysis at once'),
	async execute(interaction) {
        const DEVELOPER_ID = '110890964364627968';
        if (interaction.user.id !== DEVELOPER_ID) {
            return interaction.reply({ content: '❌ This command is restricted to the bot developer.', ephemeral: true });
        }

        if (!interaction.isRepliable()) return;
        
        try {
            await interaction.deferReply();
        } catch (e) {
            console.error('[testall] Defer failed:', e.message);
            return;
        }
        
        try {
            const { hsr, genshin, wuwa } = await fetchLiveBanners();
            const allBanners = [...hsr, ...genshin, ...wuwa];
            
            if (allBanners.length === 0) {
                return interaction.editReply('❌ No active banners found.');
            }

            // Initial reply to acknowledge the command
            await interaction.editReply(`🧪 Starting batch analysis for **${allBanners.length}** banners...`);

            for (let i = 0; i < allBanners.length; i++) {
                const banner = allBanners[i];
                const rawId = banner.id || banner.bannerId;
                const bannerId = String(rawId);
                
                try {
                    const data = await fetchWarpStats(bannerId);
                    
                    if (!data || !data.stats) {
                        await interaction.followUp(`⚠️ Could not fetch stats for **${banner.name}** (${bannerId})`);
                        continue;
                    }
                    
                    const pulls5 = data.stats.by_rollnum_pulls_5 || {};
                    const chance5 = data.stats.by_rollnum_chance_5 || {};
                    
                    const idStr = bannerId.toString();
                    const isGenshinWeapon = idStr.startsWith('400');
                    const isWuWa = idStr.length === 6 && (idStr.startsWith('1') || idStr.startsWith('2'));
                    const softPityThreshold = isGenshinWeapon ? 63 : (isWuWa ? 66 : 74);
                    
                    const peaks = detectLuckyPeaks(pulls5, chance5, { topN: 3, minZScore: 0.5 });
                    const shortcut = generateShortcutString(peaks, softPityThreshold);
                    
                    const bannerInfo = OVERRIDE_MAP[bannerId] || {};
                    const bannerName = bannerInfo.name || data._derivedName || banner.name || `Banner ${bannerId}`;
                    const bannerImage = bannerInfo.image || null;
                    
                    const hardPity = isGenshinWeapon ? 77 : (isWuWa ? 80 : 90);
                    const allPeaks = peaks.filter(p => p.roll <= hardPity);
                    let pullStrategy = '---';
                    
                    if (allPeaks.length > 0) {
                        const steps = [];
                        let currentPity = 0;
                        for (let p = 0; p < allPeaks.length; p++) {
                            const peak = allPeaks[p];
                            const rollsToReach = peak.roll - currentPity;
                            const singles = rollsToReach % 10;
                            const tens = Math.floor(rollsToReach / 10);
                            
                            if (singles > 0) {
                                steps.push(`x1 ${currentPity + 1}→${currentPity + singles} (${(peak.chance * 100).toFixed(2)}%)`);
                                currentPity += singles;
                            }
                            if (tens > 0) {
                                steps.push(`x10 ${currentPity + 1}→${currentPity + (tens * 10)} (${(peak.chance * 100).toFixed(2)}%)`);
                                currentPity += tens * 10;
                            }
                        }
                        pullStrategy = steps.join('\n');
                    }
                    
                    const embed = new EmbedBuilder()
                        .setColor(0xfbbf24)
                        .setTitle(`🎰 ${bannerName}`)
                        .setDescription(
                            `**Lucky String:** \`${shortcut}\`\n` +
                            `**Data Version:** ${data.stats.count_win_5 || 0} ${data._isWuWa ? '5★ Pulls' : 'Wins'}`
                        );

                    if (data._isWuWa) {
                        embed.addFields(
                            { name: '📊 Total Legendaries', value: `**${data.stats.count_win_5 || 0}** 5★ pulls detected`, inline: false }
                        );
                    } else {
                        embed.addFields(
                            { name: '📊 Win/Loss Count', value: `**${data.stats.count_win_5 || 0}** Wins / **${data.stats.count_lose_5 || 0}** Losses`, inline: false }
                        );
                    }

                    embed.addFields(
                        { name: '💡 How to Use', value: 'Values are **single pulls** to do before a x10.\nEx: `6` → Do 6 singles → Then x10', inline: false },
                        { name: '🎯 Pull Strategy', value: pullStrategy, inline: false }
                    )
                        .setFooter({ text: `Svarog Tracer • Warp Analyzer • Banner ID: ${bannerId}` })
                        .setTimestamp();
                    
                    if (bannerImage) {
                        embed.setThumbnail(bannerImage);
                    }
                    
                    const peakDetails = peaks.map(p => 
                        `**Roll ${p.roll}**: ${p.zScore}σ (${(p.chance * 100).toFixed(2)}%)`
                    ).join('\n');
                    
                    if (peakDetails) {
                        embed.addFields({ name: '📈 Detected Peaks', value: peakDetails });
                    }

                    await interaction.followUp({ embeds: [embed] });
                    
                    // Small delay to prevent rate limit issues
                    await new Promise(resolve => setTimeout(resolve, 500));
                    
                } catch (err) {
                    await interaction.followUp(`❌ Error analyzing **${banner.name}** (${bannerId}): ${err.message}`);
                }
            }
            
        } catch (error) {
            await interaction.editReply(`❌ Batch analysis failed: ${error.message}`);
        }
	},
};
