import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { fetchWarpStats, detectLuckyPeaks, generateShortcutString } from '../utils/botWarpService.js';
import { generateOverrideMap } from '../config/banners.js';

// Generate OVERRIDE_MAP from centralized config
const OVERRIDE_MAP = generateOverrideMap();

export default {
	data: new SlashCommandBuilder()
		.setName('st-check')
		.setDescription('Analyze a Warp Banner ID/URL for lucky strings')
		.addStringOption(option =>
			option.setName('id')
				.setDescription('Banner ID (e.g. 2099) or URL')
				.setRequired(true)),
	async execute(interaction) {
		const inputId = interaction.options.getString('id');
        let bannerId = String(inputId);
        if (inputId.includes('warp_fetch/')) {
            bannerId = inputId.split('warp_fetch/')[1].split('/')[0];
        } else if (inputId.includes('?banner=')) {
             bannerId = inputId.split('?banner=')[1].split('&')[0];
        }
        
        if (!interaction.isRepliable()) return;
        await interaction.deferReply();
        
        try {
            const data = await fetchWarpStats(bannerId);
            
            if (!data || !data.stats) {
                 return interaction.editReply('❌ Could not fetch stats. Check ID.');
            }
            
            // Format stats for Lucky Peak detection
            const pulls5 = data.stats.by_rollnum_pulls_5 || {};
            const chance5 = data.stats.by_rollnum_chance_5 || {};
            
            // Determine soft pity
            const idStr = bannerId.toString();
            const isGenshinWeapon = idStr.startsWith('400');
            const isWuWa = idStr.length === 6 && (idStr.startsWith('1') || idStr.startsWith('2'));
            const softPityThreshold = isGenshinWeapon ? 63 : (isWuWa ? 66 : 74);
            
            console.log('\n=== WCHECK DEBUG ===');
            console.log('Banner ID:', bannerId);
            console.log('Is Genshin Weapon:', isGenshinWeapon);
            console.log('Is WuWa:', isWuWa);
            console.log('Soft Pity Threshold:', softPityThreshold);
            console.log('Total 5* Wins:', data.stats.count_win_5);
            
            const peaks = detectLuckyPeaks(pulls5, chance5, { topN: 3, minZScore: 0.5 });
            console.log('All Detected Peaks:', peaks.map(p => `Roll ${p.roll} (${(p.chance * 100).toFixed(2)}%)`));
            
            const shortcut = generateShortcutString(peaks, softPityThreshold);
            console.log('Filtered Pre-Pity Peaks (<' + softPityThreshold + '):', peaks.filter(p => p.roll < softPityThreshold).map(p => p.roll));
            console.log('Final Lucky String:', shortcut);
            console.log('===================\n');
            
            // Get banner info from override map or use derived name
            const bannerInfo = OVERRIDE_MAP[bannerId] || {};
            const bannerName = bannerInfo.name || data._derivedName || `Banner ${bannerId}`;
            const bannerImage = bannerInfo.image || null;
            const bannerType = bannerInfo.type || 'unknown';
            
            // Create detailed pull strategy from ALL peaks (not just pre-soft pity)
            // Show strategy up to hard pity (90)
            const hardPity = isGenshinWeapon ? 77 : (isWuWa ? 80 : 90);
            const allPeaks = peaks.filter(p => p.roll <= hardPity);
            let pullStrategy = '---';
            
            if (allPeaks.length > 0) {
                const steps = [];
                let currentPity = 0;
                
                for (let i = 0; i < allPeaks.length; i++) {
                    const peak = allPeaks[i];
                    const rollsToReach = peak.roll - currentPity;
                    const singles = rollsToReach % 10;
                    const tens = Math.floor(rollsToReach / 10);
                    
                    // Show each step on separate lines for clarity
                    if (singles > 0) {
                        steps.push(`x1 ${currentPity + 1}→${currentPity + singles} (${(peak.chance * 100).toFixed(2)}%)`);
                        currentPity += singles;
                    }
                    if (tens > 0) {
                        steps.push(`x10 ${currentPity + 1}→${currentPity + (tens * 10)} (${(peak.chance * 100).toFixed(2)}%)`);
                        currentPity += tens * 10;
                    }
                }
                
                pullStrategy = steps.join('\n');
            }
            
            const embed = new EmbedBuilder()
                .setColor(0xfbbf24) // Amber
                .setTitle(`🎰 ${bannerName}`)
                .setDescription(
                    `**Lucky String:** \`${shortcut}\`\n` +
                    `**Data Version:** ${data.stats.count_win_5 || 0} ${data._isWuWa ? '5★ Pulls' : 'Wins'}`
                );

            if (data._isWuWa) {
                embed.addFields(
                    { name: '📊 Total Legendaries', value: `**${data.stats.count_win_5 || 0}** 5★ pulls detected`, inline: false }
                );
            } else {
                embed.addFields(
                    { name: '📊 Win/Loss Count', value: `**${data.stats.count_win_5 || 0}** Wins / **${data.stats.count_lose_5 || 0}** Losses`, inline: false }
                );
            }

            embed.addFields(
                { name: '💡 How to Use', value: 'Values are **single pulls** to do before a x10.\nEx: `6` → Do 6 singles → Then x10', inline: false },
                { name: '🎯 Pull Strategy', value: pullStrategy, inline: false }
            )
                .setFooter({ text: `Svarog Tracer • Warp Analyzer • Banner ID: ${bannerId}` })
                .setTimestamp();
            
            // Add banner image if available
            if (bannerImage) {
                embed.setThumbnail(bannerImage);
            }
                
            // Add detected peaks
            const peakDetails = peaks.map(p => 
                `**Roll ${p.roll}**: ${p.zScore}σ (${(p.chance * 100).toFixed(2)}%)`
            ).join('\n');
            
            if (peakDetails) {
                embed.addFields({ name: '📈 Detected Peaks', value: peakDetails });
            }

            await interaction.editReply({ embeds: [embed] });
            
        } catch (error) {
            console.error(error);
            await interaction.editReply(`❌ Error: ${error.message}`);
        }
	},
};
