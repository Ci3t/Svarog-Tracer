import { SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Replies with Pong and latency!'),
	async execute(interaction) {
		const sentinel = await interaction.reply({ content: 'Pinging...', fetchReply: true });
        const latency = sentinel.createdTimestamp - interaction.createdTimestamp;
		await interaction.editReply(`Pong! 🏓\nLatency: ${latency}ms\nAPI Latency: ${Math.round(interaction.client.ws.ping)}ms`);
	},
};
