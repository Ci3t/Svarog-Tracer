import fetch from 'node-fetch';

async function testWuWaScraping() {
    try {
        const url = 'https://wuwatracker.com/tracker/stats';
        console.log('Fetching', url);
        const res = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        const html = await res.text();
        
        console.log('HTML length:', html.length);
        
        // Find links to statistics
        const statsIndex = html.indexOf('/tracker/stats/');
        if (statsIndex !== -1) {
            console.log('Found stats link. Chunk:');
            console.log(html.substring(statsIndex, statsIndex + 200));
        }
        
        const bannersIndex = html.indexOf('rawBanners');
        if (bannersIndex !== -1) {
            console.log('Found rawBanners. Context:');
            console.log(html.substring(bannersIndex, bannersIndex + 5000));
        } else {
            console.log('Could not find "rawBanners" in HTML');
        }
        
        const seen = new Set();
        const banners = [];
        
        const bannerPattern = /\\"bannerId\\":\s*(\d{6})[\s\S]{1,2000}?\\"rateUp\\":\{[\s\S]{1,100}?\\"5stars\\":\[[\s\S]{1,2000}?\\"name\\":\s*\\"([^\\"]+)\\"/g;
        let bMatch;
        while ((bMatch = bannerPattern.exec(html)) !== null) {
            const id = bMatch[1];
            const name = bMatch[2];
            
            if (seen.has(id)) continue;
            seen.add(id);
            
            const isWeapon = id.startsWith('101') || id.startsWith('200');
            banners.push({ id, name, type: isWeapon ? 'weapon' : 'character' });
        }
        
        console.log('Detected Banners:');
        banners.sort((a,b) => b.id.localeCompare(a.id)).slice(0, 50).forEach(b => {
            console.log(`- [${b.id}] ${b.name} (${b.type})`);
        });
        
    } catch (e) {
        console.error('Error:', e);
    }
}

testWuWaScraping();
