// Test the regex pattern
import fs from 'fs';
const html = fs.readFileSync('wuwa-label-sample.txt', 'utf8');

console.log('HTML snippet:', html.substring(400, 600));
console.log('\n=== Testing Patterns ===');

// Pattern 1: What I currently have
const pattern1 = /\\"label\\":\\"5✦ Pulls per Pity\\"/;
console.log('Pattern 1 matches:', pattern1.test(html));

// Pattern 2: Try with different escaping
const pattern2 = /\\\"label\\\":\\\"5✦ Pulls per Pity\\\"/;
console.log('Pattern 2 matches:', pattern2.test(html));

// Pattern 3: Try to find any label
const pattern3 = /label.*5✦/;
console.log('Pattern 3 matches:', pattern3.test(html));

// Show what's actually in the HTML around the label
const idx = html.indexOf('5✦ Pulls per Pity');
if (idx > -1) {
    console.log('\nActual context (raw):');
    console.log(html.substring(idx - 30, idx + 30));
    console.log('\nActual context (JSON.stringify):');
    console.log(JSON.stringify(html.substring(idx - 30, idx + 30)));
}
