// Extract actual histogram pattern from WuWa HTML
import fetch from 'node-fetch';
import fs from 'fs';

async function testWuWaHTML() {
    const bannerId = '100031'; // Mornye
    const url = `https://wuwatracker.com/tracker/stats/${bannerId}`;
    
    console.log('Fetching:', url);
    const res = await fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });
    
    const html = await res.text();
    console.log('HTML length:', html.length);
    
    // Find histogram data
    console.log('\n=== SEARCHING FOR HISTOGRAM ===');
    
    // Pattern 1: Look for "5✦ Pulls per Pity" and extract surrounding context
    const labelIdx = html.indexOf('5✦ Pulls per Pity');
    if (labelIdx > -1) {
        console.log('Found "5✦ Pulls per Pity" at position:', labelIdx);
        const sample = html.substring(labelIdx - 500, labelIdx + 500);
        console.log('\n--- Sample around label ---');
        console.log(sample);
        fs.writeFileSync('wuwa-label-sample.txt', sample);
    }
    
    // Pattern 2: Look for histogram keyword and extract
    const histIdx = html.indexOf('"histogram"');
    if (histIdx > -1) {
        console.log('\nFound "histogram" at position:', histIdx);
        const sample = html.substring(histIdx - 200, histIdx + 1000);
        console.log('\n--- Sample around histogram ---');
        console.log(sample.substring(0, 500) + '...');
        fs.writeFileSync('wuwa-histogram-sample.txt', sample);
    }
    
    // Pattern 3: Try to extract the actual histogram object
    const histPattern = /\\"histogram\\":\{([^}]{100,})\}/;
    const match = html.match(histPattern);
    if (match) {
        console.log('\n--- Histogram data (first 500 chars) ---');
        console.log(match[1].substring(0, 500));
        fs.writeFileSync('wuwa-histogram-data.txt', match[1]);
    }
    
    console.log('\n=== Files written ===');
    console.log('- wuwa-label-sample.txt (context around label)');
    console.log('- wuwa-histogram-sample.txt (context around histogram)');
    console.log('- wuwa-histogram-data.txt (extracted histogram data)');
}

testWuWaHTML().catch(console.error);
