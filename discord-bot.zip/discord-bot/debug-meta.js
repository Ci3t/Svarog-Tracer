import fetch from 'node-fetch';

async function checkMeta() {
    try {
        console.log('Fetching StarRailRes characters.json...');
        const res = await fetch("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/characters.json");
        const data = await res.json();
        
        console.log('Total characters:', Object.keys(data).length);
        
        // Check for specific IDs
        const ids = ['23035', '23032', '3101', '3102'];
        ids.forEach(id => {
            if (data[id]) console.log(`[FOUND] ${id}: ${data[id].name}`);
            else console.log(`[MISSING] ${id}`);
        });
        
        // Search for Aglaea or similar names to find their REAL ID
        Object.entries(data).forEach(([id, info]) => {
            if (['Aglaea', 'The Herta', 'Castor', 'Pollux', 'Tribbie'].some(n => info.name.includes(n))) {
                console.log(`[NAME MATCH] ${info.name}: ${id}`);
            }
        });
        
    } catch(e) {
        console.error(e);
    }
}

checkMeta();
