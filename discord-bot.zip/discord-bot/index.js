import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client, Collection, Events, GatewayIntentBits } from 'discord.js';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const client = new Client({ 
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ] 
});

client.commands = new Collection();
const foldersPath = path.join(__dirname, 'commands');

// In ESM we can't sync require, so we read dir then dynamic import
const commandFiles = fs.readdirSync(foldersPath).filter(file => file.endsWith('.js'));

async function loadCommands() {
    for (const file of commandFiles) {
        const filePath = path.join(foldersPath, file);
        // Windows path + file:// protocol
        const fileUrl = 'file://' + filePath.replace(/\\/g, '/');
        const command = await import(fileUrl);
        
        if ('data' in command.default && 'execute' in command.default) {
            client.commands.set(command.default.data.name, command.default);
        } else {
            console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
        }
    }
}

client.once(Events.ClientReady, readyClient => {
    console.log(`Ready! Logged in as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async interaction => {
    if (interaction.isButton()) {
        const userId = interaction.user.id;
        const { getSession } = await import('./utils/sessionManager.js');
        const session = getSession(userId);
        
        if (!session) {
            return interaction.reply({ content: '❌ No active session found. Buttons expired.', ephemeral: true });
        }

        const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = await import('discord.js');
        
        if (interaction.customId === 'set_response_channel') {
            session.responseMode = 'channel';
            const row = ActionRowBuilder.from(interaction.message.components[0]);
            row.components[0].setStyle(ButtonStyle.Success).setDisabled(true);
            row.components[1].setStyle(ButtonStyle.Secondary).setDisabled(false);
            
            await interaction.update({ components: [row] });
            return interaction.followUp({ content: '📱 Output set to **Channel**.', ephemeral: true });
        }
        
        if (interaction.customId === 'set_response_dm') {
            session.responseMode = 'dm';
            const row = ActionRowBuilder.from(interaction.message.components[0]);
            row.components[0].setStyle(ButtonStyle.Secondary).setDisabled(false);
            row.components[1].setStyle(ButtonStyle.Success).setDisabled(true);
            
            await interaction.update({ components: [row] });
            return interaction.followUp({ content: '📬 Output set to **DM**.', ephemeral: true });
        }
    }

    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);

    if (!command) {
        console.error(`No command matching ${interaction.commandName} was found.`);
        return;
    }

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
        } else {
            await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
        }
    }
});

// Message listener for roll tracking (both live and longstring modes)
client.on(Events.MessageCreate, async (message) => {
    const { handleSessionInput } = await import('./utils/messageHandlers.js');
    await handleSessionInput(message);
});

// Load commands then login
loadCommands().then(async () => {
    client.login(process.env.DISCORD_TOKEN);
});
