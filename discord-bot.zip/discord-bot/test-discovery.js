import { fetchLiveBanners } from './utils/botWarpService.js';

async function testDiscovery() {
    console.log('Fetching live banners...');
    const banners = await fetchLiveBanners();
    
    console.log('\nHSR Banners:');
    banners.hsr.forEach(b => console.log(`- [${b.id}] ${b.name} (${b.type})`));
    
    console.log('\nGenshin Banners:');
    banners.genshin.forEach(b => console.log(`- [${b.id}] ${b.name} (${b.type})`));
    
    console.log('\nWuWa Banners:');
    banners.wuwa.forEach(b => console.log(`- [${b.id}] ${b.name} (${b.type})`));
}

testDiscovery();
