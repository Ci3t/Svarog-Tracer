import fetch from 'node-fetch';

// Backend API base URL
const API_BASE = process.env.BACKEND_API_URL || 'http://localhost:3000/api';

/**
 * Centralized API client for Discord bot
 * Calls the backend API instead of external APIs directly
 */
export const backendApi = {
  hsr: {
    async getStats(bannerId) {
      try {
        const response = await fetch(`${API_BASE}/hsr/stats?id=${bannerId}`);
        if (!response.ok) throw new Error(`HSR Stats API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] HSR Stats error:', error.message);
        throw error;
      }
    },
    
    async getBanners() {
      try {
        const response = await fetch(`${API_BASE}/hsr/banners`);
        if (!response.ok) throw new Error(`HSR Banners API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] HSR Banners error:', error.message);
        throw error;
      }
    }
  },
  
  genshin: {
    async getStats(bannerId) {
      try {
        const response = await fetch(`${API_BASE}/genshin/stats?id=${bannerId}`);
        if (!response.ok) throw new Error(`Genshin Stats API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] Genshin Stats error:', error.message);
        throw error;
      }
    },
    
    async getBanners() {
      try {
        const response = await fetch(`${API_BASE}/genshin/banners`);
        if (!response.ok) throw new Error(`Genshin Banners API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] Genshin Banners error:', error.message);
        throw error;
      }
    }
  },
  
  wuwa: {
    async getStats(bannerId) {
      try {
        const response = await fetch(`${API_BASE}/wuwa/stats?id=${bannerId}`);
        if (!response.ok) throw new Error(`WuWa Stats API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] WuWa Stats error:', error.message);
        throw error;
      }
    },
    
    async getBanners() {
      try {
        const response = await fetch(`${API_BASE}/wuwa/banners`);
        if (!response.ok) throw new Error(`WuWa Banners API error: ${response.status}`);
        return await response.json();
      } catch (error) {
        console.error('[Bot API] WuWa Banners error:', error.message);
        throw error;
      }
    }
  }
};
