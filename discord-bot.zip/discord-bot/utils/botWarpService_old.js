import fetch from 'node-fetch';
import { backendApi } from './apiClient.js';

const SRS_API_BASE = "https://starrailstation.com/api/v1/warp_fetch/";
const PAIMON_API_BASE = "https://api.paimon.moe/wish";

// Updated Overrides based on user feedback (2.5 Patch)
const OVERRIDE_MAP = {
    // Genshin
    "300094": { name: "Columbina", type: "character" },
    "300093": { name: "Ineffa", type: "character" },
    "400093": { name: "Nocturne's Curtain Call / Fractured Halo", type: "weapon" },
    "400092": { name: "Nocturne's Curtain Call / Fractured Halo", type: "weapon" },
    
    // HSR Character/LC IDs usually resolve via StarRailRes, 
    // but if missing or misaligned:
    "23035": { name: "Fugue LC", type: "light_cone" }, 
    "23032": { name: "Lingsha LC", type: "light_cone" },
    
    // Direct Banner ID Overrides
    "3101": { name: "Fugue LC", type: "light_cone" },
    "3102": { name: "Lingsha LC", type: "light_cone" }
};

// === FATE/STAY NIGHT COLLABORATION ===
const FATE_CHARACTERS = [
  { id: "5001", name: "Saber", type: "character", characterId: "1014" },
  { id: "5002", name: "Archer", type: "character", characterId: "1015" }
];

const FATE_LIGHT_CONES = [
  { id: "6001", name: "A Thankless Coronation", type: "light_cone" },
  { id: "6002", name: "The Hell Where Ideals Burn", type: "light_cone" }
];

// --- WuWa Background Sync ---
let WUWA_CACHE = {
    banners: [],
    lastUpdate: 0
};

export function startBackgroundSync() {
    console.log("[BG Sync] Starting background synchronization...");
    // Initial fetch
    fetchWuWaLiveBanners().then(b => {
        WUWA_CACHE.banners = b;
        WUWA_CACHE.lastUpdate = Date.now();
        console.log(`[BG Sync] Initial WuWa fetch successful: ${b.length} banners found.`);
    });

    // Every 15 minutes
    setInterval(async () => {
        try {
            console.log("[BG Sync] Fetching fresh WuWa data...");
            const b = await fetchWuWaLiveBanners();
            if (b && b.length > 0) {
                WUWA_CACHE.banners = b;
                WUWA_CACHE.lastUpdate = Date.now();
                console.log(`[BG Sync] WuWa cache updated: ${b.length} banners.`);
            }
        } catch (e) {
            console.error("[BG Sync] Sync error:", e);
        }
    }, 15 * 60 * 1000);
}

// Helper: Simple fetch with timeout (Node.js version)
async function fetchWithTimeout(url, timeoutMs = 8000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

// =========================================================================
// 1. BANNER FETCHING (Discovery)
// =========================================================================
// --- HYBRID FETCH (Cache + Live) ---
export async function fetchLiveBanners() {
    // Return cache if fresh (younger than 5 mins)
    if (WUWA_CACHE.banners.length > 0 && (Date.now() - WUWA_CACHE.lastUpdate < 5 * 60 * 1000)) {
        console.log("[fetchLiveBanners] Using cached WuWa data.");
    }

    try {
        const [hsr, genshin, wuwa] = await Promise.all([
            fetchHSRActiveBanners(),
            fetchActiveGenshinBanners(),
            WUWA_CACHE.banners.length > 0 ? WUWA_CACHE.banners : fetchWuWaLiveBanners()
        ]);
        
        return { hsr, genshin, wuwa };
    } catch (e) {
        return { hsr: [], genshin: [], wuwa: [] };
    }
}

// --- HSR LOGIC ---
export async function fetchHSRActiveBanners() {
    try {
        console.log('[Bot] Fetching HSR banners from backend...');
        const banners = await backendApi.getHSRBanners();
        
        // Convert backend format to bot format
        const liveBanners = banners.map(b => ({
            id: b.bannerId,
            name: b.name,
            type: b.type
        }));
        
        // Merge with Fate collaboration banners if needed
        return [...liveBanners, ...FATE_CHARACTERS, ...FATE_LIGHT_CONES];
    } catch (e) {
        console.error("[Bot] HSR Fetch Error:", e);
        return [];
    }
}

// --- GENSHIN LOGIC ---
export async function fetchActiveGenshinBanners() {
    try {
        console.log('[Bot] Fetching Genshin banners from backend...');
        const banners = await backendApi.getGenshinBanners();
        
        // Convert backend format to bot format
        return banners.map(b => ({
            id: b.bannerId,
            name: b.name,
            type: b.type
        }));
    } catch (e) {
        console.error("[Bot] Genshin Fetch Error:", e);
        return [];
    }
}

// --- WuWa Scraping ---
export async function fetchWuWaLiveBanners() {
    try {
        const res = await fetchWithTimeout('https://wuwatracker.com/tracker/stats', 5000);
        if (!res.ok) return [];
        const html = await res.text();
        
        // Regex to scrape banner names and IDs from escaped JSON in script tags
        // We look for bannerId and then find the nearest associated name
        const idPattern = /\\"bannerId\\":\s*(\d{6})/g;
        const banners = [];
        let idMatch;
        const seen = new Set();
        
        while ((idMatch = idPattern.exec(html)) !== null) {
            const id = idMatch[1];
            
            // Strictly filter for WuWa ID ranges
            // 100xxx: Resonators, 101xxx/200xxx: Weapons
            const isCharacter = id.startsWith('100');
            const isWeapon = id.startsWith('101') || id.startsWith('200');
            if (!isCharacter && !isWeapon) continue;

            const pos = idMatch.index;
            
            // Search forward for the name and type field
            // Use a smaller, more precise context (3000 chars is plenty for one banner object)
            const forward = html.substring(pos, pos + 3000);
            
            // Extract Pool Type (e.g. Featured Character, Featured Weapon)
            const typeMatch = forward.match(/\\"cardPoolType\\":\s*\\"([^\\"]+)\\"/);
            const poolType = typeMatch ? typeMatch[1].toLowerCase() : '';
            
            const nameMatch = forward.match(/\\"name\\":\s*\\"([^\\"]+)\\"/);
            let name = nameMatch ? nameMatch[1] : 'Unknown Banner';
            
            if (seen.has(id)) continue;
            seen.add(id);
            
            // Skip standard banner
            if (name.toLowerCase().includes('standard')) continue;
            
            // Categorize by pool type or ID prefix fallback
            const finalType = poolType.includes('character') ? 'character' : 
                             (poolType.includes('weapon') ? 'weapon' : 
                             (id.startsWith('100') ? 'character' : 'weapon'));

            banners.push({ 
                id, 
                name, 
                type: finalType,
                game: 'wuwa'
            });
        }
        
        console.log(`[WuWa Scrape] Total banners found: ${banners.length}`);
        const foundChars = banners.filter(b => b.type === 'character');
        const foundWeapons = banners.filter(b => b.type === 'weapon');
        console.log(`[WuWa Scrape] Characters: ${foundChars.length} (${foundChars.map(c => c.name).join(', ')})`);
        console.log(`[WuWa Scrape] Weapons: ${foundWeapons.length} (${foundWeapons.map(w => w.name).join(', ')})`);
        
        // Return most recent banners (Top 3 of each type to ensure balance)
        const charBanners = banners.filter(b => b.type === 'character')
            .sort((a,b) => b.id.localeCompare(a.id)).slice(0, 3);
        const weaponBanners = banners.filter(b => b.type === 'weapon')
            .sort((a,b) => b.id.localeCompare(a.id)).slice(0, 3);
            
        return [...charBanners, ...weaponBanners];
    } catch (e) {
        console.error("WuWa scrape error:", e);
        return [];
    }
}

function extractGenshinBannerName(list) {
    if (!list || list.length === 0) return null;
    
    // Standard 5-star characters
    const standard = ['Diluc', 'Jean', 'Keqing', 'Mona', 'Qiqi', 'Tighnari', 'Dehya'];
    
    // Known 4-stars to filter out case-insensitively
    const fourStarBlocklist = [
        'Fischl', 'Chevreuse', 'Bennett', 'Xiangling', 'Xingqiu', 'Barbara', 
        'Noelle', 'Sucrose', 'Diona', 'Chongyun', 'Razor', 'Beidou', 'Ningguang',
        'Yanfei', 'Rosaria', 'Xinyan', 'Sayu', 'Kujou Sara', 'Thoma', 'Gorou',
        'Yun Jin', 'Kuki Shinobu', 'Heizou', 'Collei', 'Dori', 'Candace', 'Layla',
        'Faruzan', 'Yaoyao', 'Mika', 'Kaveh', 'Kirara', 'Lynette', 'Freminet',
        'Charlotte', 'Gaming', 'Sethos', 'Kachina'
    ].map(n => n.toLowerCase());

    // Filter characters
    const characterCandidates = list.filter(item => {
        if (item.type !== 'character') return false;
        
        const nameLower = item.name.toLowerCase();
        
        // 1. Exclude standard 5-stars
        if (standard.some(s => s.toLowerCase() === nameLower)) return false;
        
        // 2. Exclude known 4-stars
        if (fourStarBlocklist.includes(nameLower)) return false;
        
        // 3. Count Heuristic (5-stars usually have 300-40000 pulls globally)
        // Correcting the threshold to capture new 5-stars but skip massive 4-star pools
        return item.count > 300 && item.count < 35000;
    });

    // Sort by count descending (most relevant 5-star)
    characterCandidates.sort((a, b) => b.count - a.count);
    
    if (characterCandidates.length > 0) {
        // Format name (e.g. raiden_shogun -> Raiden Shogun)
        return characterCandidates[0].name.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    }
    
    return null;
}

function extractGenshinWeaponNames(list) {
    if (!list || list.length === 0) return null;
    
    const standardWeapons = [
        'amos_bow', 'skyward_harp', 'skyward_atlas', 'lost_prayer_to_the_sacred_winds',
        'primordial_jade_winged_spear', 'skyward_spine', 'wolfs_gravestone', 'skyward_pride',
        'skyward_blade', 'aquila_favonia'
    ].map(n => n.toLowerCase());

    const weaponCandidates = list.filter(item => {
        if (item.type !== 'weapon') return false;
        const nameLower = item.name.toLowerCase();
        if (standardWeapons.includes(nameLower)) return false;
        
        // Exclude common 4-star weapons often found in weapon banners
        const weapon4StarBlocklist = [
            'mitternachts_waltz', 'mountain-bracing_bolt', 'winters_vigil', 'lithic_blade', 
            'lithic_spear', 'wavebreakers_fin', 'akuoumaru', 'mounns_moon', 'rust',
            'favonius_warbow', 'eye_of_perception', 'the_flute', 'the_bell'
        ];
        if (weapon4StarBlocklist.includes(nameLower)) return false;

        return item.count > 200 && item.count < 35000;
    });

    weaponCandidates.sort((a, b) => b.count - a.count);
    
    if (weaponCandidates.length > 0) {
        // Take top 2 weapons (dual featured)
        return weaponCandidates.slice(0, 2).map(item => 
            item.name.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
        ).join(' / ');
    }
    
    return null;
}

/**
 * Transforms Paimon.moe data to match Svarog format (Ported from warpDataService.js)
 */
function transformGenshinData(data, bannerId) {
    const pityArray = data.pityCount?.legendary || [];
    const by_rollnum_pulls_5 = {};
    const by_rollnum_chance_5 = {};
    
    let totalPulls = 0;
    pityArray.forEach((count, index) => {
        const roll = index + 1;
        by_rollnum_pulls_5[roll] = count;
        totalPulls += count;
    });
    
    if (totalPulls > 0) {
        for (const [roll, count] of Object.entries(by_rollnum_pulls_5)) {
            by_rollnum_chance_5[roll] = count / totalPulls;
        }
    }
    
    const { countWin, countLose } = calculateGenshinWinLoss(data.list, bannerId);
    
    return {
        stats: {
            total_pulls_5: data.total?.legendary || totalPulls,
            by_rollnum_pulls_5,
            by_rollnum_chance_5,
            count_win_5: countWin,
            count_lose_5: countLose
        }
    };
}
function calculateGenshinWinLoss(list, bannerId) {
    if (!list || list.length === 0) return { countWin: 0, countLose: 0 };
    
    const standardPool = ['diluc', 'jean', 'keqing', 'mona', 'qiqi', 'tighnari', 'dehya', 'amos_bow', 'skyward_harp', 'skyward_atlas', 'lost_prayer_to_the_sacred_winds', 'primordial_jade_winged_spear', 'skyward_spine', 'wolfs_gravestone', 'skyward_pride', 'skyward_blade', 'aquila_favonia'];
    
    const featuredItems = list.filter(item => 
        (item.type === 'character' || item.type === 'weapon') && 
        !standardPool.includes(item.name) &&
        item.count > 500
    );
    
    const standardItems = list.filter(item => 
        (item.type === 'character' || item.type === 'weapon') && 
        standardPool.includes(item.name)
    );
    
    let totalWins = 0;
    for (const item of featuredItems) {
        totalWins += (item.count || 0) - (item.guaranteed || 0);
    }
    
    let totalLosses = 0;
    for (const item of standardItems) {
        totalLosses += item.count || 0;
    }
    
    return { countWin: totalWins, countLose: totalLosses };
}

// =========================================================================
// 2. LUCKY PEAKS LOGIC
// =========================================================================

export function consolidatePeaks(peaks, minDistance = 10) {
  if (!peaks || peaks.length === 0) return [];
  const sorted = [...peaks].sort((a, b) => a.roll - b.roll);
  const consolidated = [];
  for (const peak of sorted) {
    const lastPeak = consolidated[consolidated.length - 1];
    if (!lastPeak || (peak.roll - lastPeak.roll) >= minDistance) {
      consolidated.push(peak);
    } else {
      if (peak.chance > lastPeak.chance) consolidated[consolidated.length - 1] = peak;
    }
  }
  return consolidated;
}

export function detectLuckyPeaks(pullsData, chanceData, options = {}) {
  const {
    softPityStart = 74,
    softPityEnd = 90,
    topN = 3,
    topNPreSoftPity = 8,
    topNSoftPity = 3,
    minZScore = 0.5
  } = options;

  if (!chanceData || Object.keys(chanceData).length === 0) return [];

  const calculateZScores = (data, start, end) => {
    const values = [];
    for (let i = start; i <= end; i++) values.push(data[i] || 0);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const stdDev = Math.sqrt(values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length);
    const zScores = {};
    for (let i = start; i <= end; i++) {
        const value = data[i] || 0;
        zScores[i] = stdDev > 0 ? (value - mean) / stdDev : 0;
    }
    return { zScores };
  };

  const isLocalMax = (data, roll) => {
    const prev = data[roll - 1] || 0;
    const curr = data[roll] || 0;
    const next = data[roll + 1] || 0;
    return curr > prev && curr > next;
  };

  const analyzeSegment = (start, end, topN, zoneName) => {
    const segmentAnalysis = calculateZScores(chanceData, start, end);
    const rolls = [];
    for (let roll = start; roll <= end; roll++) {
      const chance = chanceData[roll] || 0;
      const zScore = segmentAnalysis.zScores[roll] || 0;
      const isPeak = isLocalMax(chanceData, roll);
      const compositeScore = zScore + (isPeak ? 0.5 : 0);
      if (zScore >= minZScore || isPeak) {
        rolls.push({
          roll,
          chance,
          zScore: typeof zScore === 'number' ? zScore.toFixed(2) : zScore,
          isPeak,
          compositeScore,
          zone: zoneName
        });
      }
    }
    rolls.sort((a, b) => b.compositeScore - a.compositeScore);
    return rolls.slice(0, topN);
  };

  const topPreSoftPity = [
      ...analyzeSegment(1, 24, topN, "pre-soft"),
      ...analyzeSegment(25, 48, topN, "pre-soft"),
      ...analyzeSegment(49, Math.min(73, (softPityStart || 74) - 1), topN, "pre-soft")
  ];

  const softPityAnalysis = calculateZScores(chanceData, softPityStart, softPityEnd);
  const softPityRolls = [];
  for (let roll = softPityStart; roll <= softPityEnd; roll++) {
    const chance = chanceData[roll] || 0;
    const zScore = softPityAnalysis.zScores[roll] || 0;
    const isPeak = isLocalMax(chanceData, roll);
    softPityRolls.push({
      roll,
      chance,
      zScore: typeof zScore === 'number' ? zScore.toFixed(2) : zScore,
      isPeak,
      zone: "soft-pity"
    });
  }
  softPityRolls.sort((a, b) => b.chance - a.chance);
  
  const consolidatedPeaks = consolidatePeaks([...topPreSoftPity, ...softPityRolls.slice(0, topNSoftPity)], 10);
  // Return all consolidated peaks, sorted by roll number (matching website behavior)
  return consolidatedPeaks.sort((a, b) => a.roll - b.roll);
}

// =========================================================================
// 3. FETCH WARP STATS (from SRS/Paimon)
// =========================================================================

export async function fetchWarpStats(bannerId) {
  if (!bannerId) throw new Error("Banner ID required");
  
  const idStr = String(bannerId);
  const cacheBuster = Date.now();
  let targetUrl;
  let bannerName = "Unknown Banner";
  
  // DETECT GAME BASED ON ID PATTERN    
  // Genshin Banner
  if (idStr.startsWith('3') || idStr.startsWith('4')) {
      targetUrl = `${PAIMON_API_BASE}?banner=${bannerId}&_t=${cacheBuster}`;
  } 
  // WuWa Banner - requires HTML scraping
  // WuWa Banner - IDs are 6 digits starting with 100 or 200
  else if (idStr.length === 6 && (idStr.startsWith('1') || idStr.startsWith('2'))) {
      // Fetch and parse WuWa Tracker HTML
      const wuwaUrl = `https://wuwatracker.com/tracker/stats/${bannerId}`;
      const response = await fetchWithTimeout(wuwaUrl, 8000);
      if (!response.ok) throw new Error(`WuWa fetch failed: ${response.status}`);
      
      const html = await response.text();
      
      // Extract banner name from page title
      const titleMatch = html.match(/<title>([^<]+)<\/title>/i);
      let bannerName = `WuWa Banner ${bannerId}`;
      if (titleMatch) {
          // Title format: "Lynae - WuWa Tracker"
          const fullTitle = titleMatch[1].trim();
          const namePart = fullTitle.split(' - ')[0].trim();
          if (namePart && !namePart.toLowerCase().includes('wuwa')) {
              bannerName = namePart;
          }
      }
      
      // Extract histogram data from HTML
      const histPattern = /\{\\\"histogram\\\":\{([^}]+)\}[^}]*\\\"label\\\":\\\"5✦ Pulls per Pity\\\"/;
      const histMatch = html.match(histPattern);
      if (!histMatch) throw new Error('Could not parse WuWa histogram');
      
      let histogramContent = histMatch[1].replace(/\\"/g, '"');
      const histogramJson = `{${histogramContent}}`;
      const histogramData = JSON.parse(histogramJson);
      
      // Extract character/weapon data
      const charPattern = /\\\"itemNameHistogram\\\":\{([^}]+)\}/;
      const charMatch = html.match(charPattern);
      let total_pulls_5;
      
      if (charMatch) {
          let charContent = charMatch[1].replace(/\\"/g, '"');
          const charJson = `{${charContent}}`;
          const characterData = JSON.parse(charJson);
          const items = Object.entries(characterData).map(([name, count]) => ({ name, count: parseInt(count, 10) }));
          items.sort((a, b) => b.count - a.count);
          const featured = items[0];
          
          // Weapon vs Character detection
          const isWeaponBanner = items.length <= 4;
          total_pulls_5 = isWeaponBanner ? Math.floor(featured.count * 1.3) : featured.count * 2;
      } else {
          total_pulls_5 = Object.values(histogramData).reduce((sum, count) => sum + parseInt(count, 10), 0);
      }
      
      // Transform to our format
      const by_rollnum_pulls_5 = {};
      const by_rollnum_chance_5 = {};
      
      for (const [pity, count] of Object.entries(histogramData)) {
          const roll = parseInt(pity, 10);
          const pullCount = parseInt(count, 10);
          by_rollnum_pulls_5[roll] = pullCount;
          by_rollnum_chance_5[roll] = total_pulls_5 > 0 ? pullCount / total_pulls_5 : 0;
      }
      
      return {
          stats: {
              total_pulls_5,
              by_rollnum_pulls_5,
              by_rollnum_chance_5,
              count_win_5: 0,  // WuWa doesn't have 50/50 for featured
              count_lose_5: 0
          },
          _derivedName: bannerName
      };
  }
  // HSR Banner
  else {
      targetUrl = `${SRS_API_BASE}${bannerId}/?_t=${cacheBuster}`;
  }
  
  const response = await fetchWithTimeout(targetUrl);
  if (!response.ok) {
      console.error(`[fetchWarpStats] Error ${response.status} for ${targetUrl}`);
      throw new Error(`Failed to fetch stats: ${response.status} for ${targetUrl}`);
  }
  
  const data = await response.json();
  
  // Derive name
  if (idStr.startsWith('3') || idStr.startsWith('4')) {
      const transformed = transformGenshinData(data, bannerId);
      const extracted = OVERRIDE_MAP[bannerId]?.name || extractGenshinBannerName(data.list);
      if (extracted) transformed._derivedName = extracted;
      return transformed;
  } else if (bannerId === '2099') {
      data._derivedName = "Global Stats (All Time)";
  } else {
      // Try override or generic
      data._derivedName = OVERRIDE_MAP[bannerId]?.name || `HSR Data (${bannerId})`;
  }
  
  return data;
}

export function generateShortcutString(peaks, softPityStart = 74) {
    if (!peaks || peaks.length === 0) return "---";
    const prePityPeaks = peaks.filter(p => p.roll < softPityStart).sort((a, b) => a.roll - b.roll);
    if (prePityPeaks.length === 0) return "---";
    return prePityPeaks.map(p => (p.roll % 10).toString()).join(" ");
}
