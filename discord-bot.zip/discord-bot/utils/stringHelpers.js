// String decoder for longstring mode (1:1 copy from website)

// Caesar decode table: "rowcol" -> actual 2-str roll ("41".."44")
const LONG_CAESAR_DECODE = {
  // Row 1
  11: "44",
  12: "41",
  13: "42",
  14: "43",
  // Row 2
  21: "43",
  22: "44",
  23: "41",
  24: "42",
  // Row 3
  31: "42",
  32: "43",
  33: "44",
  34: "41",
  // Row 4 (pure row – no Caesar shift)
  41: "41",
  42: "42",
  43: "43",
  44: "44",
};

/**
 * Decode a long string like "41242323" into:
 *  - cleaned: only digits 1–4
 *  - pairs: sliding Caesar pairs: ["41","12","24","42","23","32","23"]
 *  - rolls: decoded 2-str rolls: ["41","41","42","42","41","43","41"]
 *
 * Example:
 *   decodeLongString("41242323")
 *   => { cleaned: "41242323",
 *        pairs: ["41","12","24","42","23","32","23"],
 *        rolls: ["41","41","42","42","41","43","41"] }
 */
export function decodeLongString(longStrRaw = "") {
  const digits = String(longStrRaw)
    .split("")
    .map((d) => {
      const n = parseInt(d, 10);
      if (isNaN(n)) return null;
      // ✅ MAP 1–9 → 1–4 USING MODULO (GAME-NATIVE)
      return ((n - 1) % 4) + 1;
    })
    .filter(Boolean)
    .map(String);

  const cleaned = digits.join("");

  if (cleaned.length < 2) {
    return { cleaned, pairs: [], rolls: [] };
  }

  const pairs = [];
  const rolls = [];

  for (let i = 0; i < cleaned.length - 1; i++) {
    const pair = cleaned.slice(i, i + 2);
    pairs.push(pair);

    // ✅ SAME CAESAR DECODE TABLE AS BEFORE
    const roll = LONG_CAESAR_DECODE[pair];
    if (roll) {
      rolls.push(roll);
    }
  }

  return { cleaned, pairs, rolls };
}
