// Message listener handlers for live and longstring sessions
import { getSession, addRoll, isExpired, endSession } from './sessionManager.js';
import { predictWithPairs } from './predictor.js';
import { decodeLongString } from './stringHelpers.js';

/**
 * Get session status with time remaining
 */
function getSessionStatus(session) {
    if (!session.hasTimer) {
        return {
            badge: '🔵',
            status: 'ACTIVE',
            timeLeft: 'No timer',
            color: 0x3b82f6 // blue
        };
    }
    
    const now = Date.now();
    const elapsed = now - session.startTime;
    const timeoutMs = session.timerMinutes * 60 * 1000;
    const remaining = timeoutMs - elapsed;
    
    if (remaining <= 0) {
        return {
            badge: '🔴',
            status: 'EXPIRED',
            timeLeft: 'Expired',
            color: 0xef4444 // red
        };
    }
    
    const remainingSeconds = Math.floor(remaining / 1000);
    const minutes = Math.floor(remainingSeconds / 60);
    const seconds = remainingSeconds % 60;
    
    // Expiring soon if < 1 minute
    if (remainingSeconds < 60) {
        return {
            badge: '🟡',
            status: 'EXPIRING SOON',
            timeLeft: `${seconds}s left`,
            color: 0xfbbf24 // amber
        };
    }
    
    return {
        badge: '🟢',
        status: 'ACTIVE',
        timeLeft: `${minutes}m ${seconds}s left`,
        color: 0x10b981 // green
    };
}

/**
 * Handle longstring mode input
 */
export async function handleLongstringInput(message, session) {
    const input = message.content.trim();
    
    // Validate: only digits 1-9
    if (!/^[1-9]+$/.test(input)) return false; // Not valid longstring input
    
    // Append to raw string
    session.rawString += input;
    
    // Decode the accumulated string
    const decoded = decodeLongString(session.rawString);
    
    // Update session rolls
    session.rolls = decoded.rolls;
    session.lastActivity = Date.now();
    
    const rollCount = session.rolls.length;
    const progress = Math.min(rollCount, 6);
    const progressBar = '▰'.repeat(progress) + '▱'.repeat(6 - progress);
    
    // Show progress with modern design
    if (rollCount < 6) {
        const progressEmbed = {
            color: 0x10b981, // emerald
            title: '🧪 Longstring Received',
            description: `✅ **${input.length} digit(s) added** (${rollCount}/6 rolls)\n\n\`${progressBar}\`\n\nNeed **${6 - rollCount}** more rolls to start predicting.`,
            fields: [
                { name: '📋 Current String', value: `\`${session.rawString}\``, inline: false },
                { name: '🔍 Recent Decoded', value: `\`${decoded.rolls.slice(-5).join(' → ')}\``, inline: false }
            ],
            footer: { text: `Latest input: ${input}` }
        };

        if (session.responseMode === 'dm' && session.user) {
            await session.user.send({ embeds: [progressEmbed] }).catch(async () => {
                await message.reply({ content: '❌ Unable to DM you! Reverting to channel output.', ephemeral: true });
                session.responseMode = 'channel';
                await message.reply({ embeds: [progressEmbed] });
            });
        } else {
            await message.reply({ embeds: [progressEmbed] }).catch(() => {});
        }
        return true;
    }
    
    // Roll 6+: Generate prediction
    try {
        const prediction = predictWithPairs(session.rolls);
        
        if (!prediction || !prediction.prediction) {
            await message.reply({
                content: '❌ Unable to generate prediction. Try adding more rolls.',
            }).catch(() => {});
            return true;
        }
        
        // Get session status
        const status = getSessionStatus(session);
        
        const confPct = Math.min(100, Math.round((prediction.confidence || 0.5) * 100));
        
        // Build prediction embed with modern design
        const embed = {
            color: status.color,
            title: `${status.badge} LONGSTRING PREDICTION`,
            description: `**Next Roll:** \`${prediction.prediction}\` **(${confPct}% confidence)**` +
                         (prediction.alt ? `\n**Alternative:** \`${prediction.alt}\`` : ''),
            fields: [
                {
                    name: '⏱️ Session Info',
                    value: `**Status:** ${status.status}\n**Time:** ${status.timeLeft}\n**Rolls:** ${rollCount} total`,
                    inline: true
                },
                {
                    name: '📊 Pattern Analysis',
                    value: prediction.commons && prediction.commons.length > 0
                        ? `**Commons:** ${prediction.commons.join(', ')}\n**Noise:** ${prediction.noise ? prediction.noise.join(', ') : '—'}`
                        : 'Analyzing patterns...',
                    inline: true
                }
            ]
        };
        
        // Helper to get trend icon
        const getTrendIcon = (value) => {
            const trend = prediction.trends?.[value]?.direction;
            if (trend === 'rising') return '⬆️';
            if (trend === 'falling') return '⬇️';
            return '➡️';
        };

        // Add Session Frequency (Wide + Trends)
        if (prediction.fullDistribution) {
            const freqVals = ['41', '42', '43', '44'].map(v => {
                const pct = prediction.fullDistribution[v] || 0;
                const trendIcon = getTrendIcon(v);
                // Extra Wide: 25 characters
                const bar = '█'.repeat(Math.floor(pct / 4)) + '░'.repeat(25 - Math.floor(pct / 4));
                return `\`${v}\` ${bar} **${pct}%** ${trendIcon}`;
            }).join('\n');

            embed.fields.push({
                name: '📊 Overall Session Frequency',
                value: freqVals,
                inline: false
            });
        }

        // Add transition matrix if available
        if (prediction.pairMatrix && prediction.lastRoll) {
            const lastRollData = prediction.pairMatrix[prediction.lastRoll];
            const totalSamples = Object.values(lastRollData || {}).reduce((sum, d) => sum + (d.samples || 0), 0);

            if (totalSamples === 0) {
                embed.fields.push({
                    name: `🎯 After ${prediction.lastRoll} → Next Roll Probability`,
                    value: `*Waiting for more data after \`${prediction.lastRoll}\`... (First time seen)*`,
                    inline: false
                });
            } else {
                const afterVals = ['41', '42', '43', '44'].map(v => {
                    const data = lastRollData?.[v];
                    const pct = data?.pct || 0;
                    const samples = data?.samples || 0;
                    // Extra Wide: 25 characters
                    const bar = '█'.repeat(Math.floor(pct / 4)) + '░'.repeat(25 - Math.floor(pct / 4));
                    return `\`${v}\` ${bar} **${pct}%** (${samples} samples)`;
                }).join('\n');
                
                embed.fields.push({
                    name: `🎯 After ${prediction.lastRoll} → Next Roll Probability`,
                    value: afterVals,
                    inline: false
                });
            }
        }
        
        // Add decoded rolls
        const last12 = session.rolls.slice(-12);
        embed.fields.push({
            name: '📝 Recent Decoded Rolls',
            value: `\`${last12.join(' → ')}\``,
            inline: false
        });
        
        // Add raw string info
        const rawPreview = session.rawString.length > 30 
            ? '...' + session.rawString.slice(-30)
            : session.rawString;
        embed.fields.push({
            name: '📏 Raw Input String',
            value: `${session.rawString.length} characters: \`${rawPreview}\``,
            inline: false
        });
        
        embed.footer = { 
            text: `Method: ${prediction.method || 'pair-matrix'} • Longstring Mode` 
        };
        embed.timestamp = new Date();
        
        if (session.responseMode === 'dm' && session.user) {
            await session.user.send({ embeds: [embed] }).catch(async () => {
                await message.reply({ content: '❌ Unable to DM you! Reverting to channel output.', ephemeral: true });
                session.responseMode = 'channel';
                await message.reply({ embeds: [embed] });
            });
        } else {
            await message.reply({
                embeds: [embed],
            }).catch(() => {});
        }
        
        return true;
        
    } catch (error) {
        console.error('[MessageListener] Longstring prediction error:', error);
        await message.reply({
            content: '❌ Error generating prediction. Please try again.',
        }).catch(() => {});
        return true;
    }
}

/**
 * Handle live mode input (2-digit rolls)
 */
export async function handleLiveInput(message, session) {
    const input = message.content.trim();
    
    // Check if it's a 2-digit number
    if (!/^\d{2}$/.test(input)) return false; // Not a 2-digit number
    
    const firstDigit = parseInt(input[0]);
    const secondDigit = parseInt(input[1]);
    
    // Both digits must be 1-4
    if (firstDigit < 1 || firstDigit > 4 || secondDigit < 1 || secondDigit > 4) return false;
    
    // Caesar shift to convert to 4x format
    const shift = (4 - firstDigit + 4) % 4;
    const z = secondDigit - 1;
    const s = (z + shift) % 4;
    const newSecondDigit = s + 1;
    const roll = '4' + newSecondDigit;
    
    // Add roll to session
    addRoll(message.author.id, roll);
    
    const rollCount = session.rolls.length;
    const progress = Math.min(rollCount, 6);
    const progressBar = '▰'.repeat(progress) + '▱'.repeat(6 - progress);
    
    // Rolls 1-5: Just acknowledge with modern design
    if (rollCount < 6) {
        const rollEmbed = {
            color: 0x9333ea, // purple
            title: '🎲 Roll Recorded',
            description: `✅ **Roll ${rollCount}/6**\n\n\`${progressBar}\`\n\nNeed **${6 - rollCount}** more rolls to start predicting.`,
            fields: [
                { name: '🎯 Decoded Roll', value: `\`${roll}\``, inline: true },
                { name: '📝 Sequence', value: `\`${session.rolls.join(' → ')}\``, inline: true }
            ]
        };

        if (session.responseMode === 'dm' && session.user) {
            await session.user.send({ embeds: [rollEmbed] }).catch(async () => {
                await message.reply({ content: '❌ Unable to DM you! Reverting to channel output.', ephemeral: true });
                session.responseMode = 'channel';
                await message.reply({ embeds: [rollEmbed] });
            });
        } else {
            await message.reply({ embeds: [rollEmbed] }).catch(() => {});
        }
        return true;
    }
    
    // Roll 6+: Generate prediction
    try {
        const prediction = predictWithPairs(session.rolls);
        
        if (!prediction || !prediction.prediction) {
            await message.reply({
                content: '❌ Unable to generate prediction. Try adding more rolls.',
            }).catch(() => {});
            return true;
        }
        
        // Get session status
        const status = getSessionStatus(session);
        
        const confPct = Math.min(100, Math.round((prediction.confidence || 0.5) * 100));

        // Build prediction embed with modern design
        const embed = {
            color: status.color,
            title: `${status.badge} LIVE PREDICTION`,
            description: `**Next Roll:** \`${prediction.prediction}\` **(${confPct}% confidence)**` +
                         (prediction.alt ? `\n**Alternative:** \`${prediction.alt}\`` : ''),
            fields: [
                {
                    name: '⏱️ Session Info',
                    value: `**Status:** ${status.status}\n**Time:** ${status.timeLeft}\n**Rolls:** ${rollCount} total`,
                    inline: true
                },
                {
                    name: '📊 Pattern Analysis',
                    value: prediction.commons && prediction.commons.length > 0
                        ? `**Commons:** ${prediction.commons.join(', ')}\n**Noise:** ${prediction.noise ? prediction.noise.join(', ') : '—'}`
                        : 'Analyzing patterns...',
                    inline: true
                }
            ]
        };
        
        // Helper to get trend icon
        const getTrendIcon = (value) => {
            const trend = prediction.trends?.[value]?.direction;
            if (trend === 'rising') return '⬆️';
            if (trend === 'falling') return '⬇️';
            return '➡️';
        };

        // Add Session Frequency (Wide + Trends)
        if (prediction.fullDistribution) {
            const freqVals = ['41', '42', '43', '44'].map(v => {
                const pct = prediction.fullDistribution[v] || 0;
                const trendIcon = getTrendIcon(v);
                // Extra Wide: 25 characters
                const bar = '█'.repeat(Math.floor(pct / 4)) + '░'.repeat(25 - Math.floor(pct / 4));
                return `\`${v}\` ${bar} **${pct}%** ${trendIcon}`;
            }).join('\n');

            embed.fields.push({
                name: '📊 Overall Session Frequency',
                value: freqVals,
                inline: false
            });
        }

        // Add transition matrix with progress bars
        if (prediction.pairMatrix && prediction.lastRoll) {
            const lastRollData = prediction.pairMatrix[prediction.lastRoll];
            const totalSamples = Object.values(lastRollData || {}).reduce((sum, d) => sum + (d.samples || 0), 0);

            if (totalSamples === 0) {
                embed.fields.push({
                    name: `🎯 After ${prediction.lastRoll} → Next Roll Probability`,
                    value: `*Waiting for more data after \`${prediction.lastRoll}\`... (First time seen)*`,
                    inline: false
                });
            } else {
                const afterVals = ['41', '42', '43', '44'].map(v => {
                    const data = lastRollData?.[v];
                    const pct = data?.pct || 0;
                    const samples = data?.samples || 0;
                    // Extra Wide: 25 characters
                    const bar = '█'.repeat(Math.floor(pct / 4)) + '░'.repeat(25 - Math.floor(pct / 4));
                    return `\`${v}\` ${bar} **${pct}%** (${samples} samples)`;
                }).join('\n');
                
                embed.fields.push({
                    name: `🎯 After ${prediction.lastRoll} → Next Roll Probability`,
                    value: afterVals,
                    inline: false
                });
            }
        }
        
        // Add last 12 rolls
        const last12 = session.rolls.slice(-12);
        embed.fields.push({
            name: '📝 Recent Rolls',
            value: `\`${last12.join(' → ')}\``,
            inline: false
        });
        
        embed.footer = { 
            text: `Method: ${prediction.method || 'pair-matrix'} • Live Mode` 
        };
        embed.timestamp = new Date();
        
        if (session.responseMode === 'dm' && session.user) {
            await session.user.send({ embeds: [embed] }).catch(async () => {
                await message.reply({ content: '❌ Unable to DM you! Reverting to channel output.', ephemeral: true });
                session.responseMode = 'channel';
                await message.reply({ embeds: [embed] });
            });
        } else {
            await message.reply({
                embeds: [embed],
            }).catch(() => {});
        }
        
        return true;
        
    } catch (error) {
        console.error('[MessageListener] Prediction error:', error);
        await message.reply({
            content: '❌ Error generating prediction. Please try again.',
        }).catch(() => {});
        return true;
    }
}

/**
 * Main message handler - routes to live or longstring
 */
export async function handleSessionInput(message) {
    // Ignore bot messages
    if (message.author.bot) return;
    
    // Only process in guild channels
    if (!message.guild) return;
    
    const userId = message.author.id;
    const session = getSession(userId);
    
    // No active session
    if (!session) return;
    
    // Check if expired
    if (isExpired(userId)) {
        endSession(userId);
        const timerText = session.hasTimer ? `${session.timerMinutes}min window` : 'manually';
        await message.reply({
            content: `⚠️ **Session Expired** (${timerText})\nPatterns may have shifted.\n\nUse \`/st-${session.mode === 'longstring' ? 'longstring' : 'session'} start\` to begin a new session.`
        }).catch(() => {});
        return;
    }
    
    // Route to appropriate handler
    if (session.mode === 'longstring') {
        await handleLongstringInput(message, session);
    } else {
        await handleLiveInput(message, session);
    }
}
