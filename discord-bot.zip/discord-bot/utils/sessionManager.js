// Session Manager for Live Prediction
// Handles per-user session tracking with 5-minute expiry

const activeSessions = new Map(); // userId -> SessionData

// Session cleanup interval (remove expired sessions every 5 minutes)
setInterval(() => {
  const now = Date.now();
  const FIVE_MINUTES = 5 * 60 * 1000;
  
  for (const [userId, session] of activeSessions.entries()) {
    // Check total duration from START, not last activity
    if (now - session.startTime > FIVE_MINUTES) {
      activeSessions.delete(userId);
      console.log(`[SessionManager] Cleaned up expired session for user ${userId}`);
    }
  }
}, 5 * 60 * 1000); // Run every 5 minutes

/**
 * Create a new session for a user
 * @param {string} userId - Discord user ID
 * @param {object} options - Session options
 * @param {boolean} options.hasTimer - Whether session has a timer (default: true)
 * @param {number} options.timerMinutes - Timer duration in minutes (default: 5)
 * @param {string} options.mode - Session mode: 'live' or 'longstring' (default: 'live')
 * @param {object} options.user - Discord user object for DM notifications
 */
function createSession(userId, options = {}) {
  const { hasTimer = true, timerMinutes = 5, mode = 'live', user = null } = options;
  
  const session = {
    userId,
    rolls: [],
    rawString: '', // For longstring mode
    startTime: Date.now(),
    lastActivity: Date.now(),
    region: 'Global', // Default region
    hasTimer,
    timerMinutes,
    mode,
    responseMode: 'channel', // Default to channel, updated via buttons
    user, // Store Discord user object for DM routing
    expiryTimeout: null
  };
  
  // Schedule auto-expiry cleanup if timer enabled
  if (hasTimer) {
    const timeoutMs = timerMinutes * 60 * 1000;
    session.expiryTimeout = setTimeout(() => {
      // Check if session still exists
      const currentSession = activeSessions.get(userId);
      if (currentSession && currentSession === session) {
        // Clean up the session
        activeSessions.delete(userId);
        console.log(`[SessionManager] Auto-expired ${mode} session for user ${userId}`);
      }
    }, timeoutMs);
  }
  
  activeSessions.set(userId, session);
  console.log(`[SessionManager] Created ${mode} session for user ${userId} (timer: ${hasTimer ? timerMinutes + 'min' : 'none'})`);
  return session;
}

/**
 * Get active session for a user
 */
function getSession(userId) {
  return activeSessions.get(userId) || null;
}

/**
 * Update session activity timestamp
 */
function updateActivity(userId) {
  const session = activeSessions.get(userId);
  if (session) {
    session.lastActivity = Date.now();
  }
}

/**
 * Add a roll to the session
 */
function addRoll(userId, roll) {
  const session = activeSessions.get(userId);
  if (!session) return null;
  
  session.rolls.push(roll);
  session.lastActivity = Date.now();
  
  return session;
}

/**
 * Check if session is expired (>X minutes from START)
 * Matches website behavior - Xmin window for pattern validity
 */
function isExpired(userId) {
  const session = activeSessions.get(userId);
  if (!session) return true;
  
  // If session has no timer, it never expires
  if (!session.hasTimer) return false;
  
  const now = Date.now();
  const timeoutMs = session.timerMinutes * 60 * 1000;
  
  // Check total duration from session START, not last activity
  return (now - session.startTime) > timeoutMs;
}

/**
 * End a session manually
 */
function endSession(userId) {
  const session = activeSessions.get(userId);
  
  // Clear expiry timeout if exists
  if (session?.expiryTimeout) {
    clearTimeout(session.expiryTimeout);
  }
  
  activeSessions.delete(userId);
  console.log(`[SessionManager] Ended session for user ${userId}`);
  return session;
}

/**
 * Get session stats
 */
function getSessionStats(userId) {
  const session = activeSessions.get(userId);
  if (!session) return null;
  
  const now = Date.now();
  const duration = Math.floor((now - session.startTime) / 1000); // seconds
  const timeSinceLastRoll = Math.floor((now - session.lastActivity) / 1000);
  
  return {
    rollCount: session.rolls.length,
    duration,
    timeSinceLastRoll,
    isExpired: isExpired(userId)
  };
}

export {
  createSession,
  getSession,
  updateActivity,
  addRoll,
  isExpired,
  endSession,
  getSessionStats
};
