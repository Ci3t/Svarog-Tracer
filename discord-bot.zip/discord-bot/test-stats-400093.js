import { fetchWarpStats } from './utils/botWarpService.js';

async function testStats() {
    const id = '400093';
    console.log(`Fetching stats for ${id}...`);
    try {
        const stats = await fetchWarpStats(id);
        console.log('Success!');
        console.log('Name:', stats._derivedName);
        console.log('Total Pulls:', stats.stats.total_pulls_5);
    } catch (e) {
        console.error('FAILED:', e.message);
    }
}

testStats();
