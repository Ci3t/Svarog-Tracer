import fetch from 'node-fetch';

async function checkLC() {
    try {
        console.log('Fetching Light Cones...');
        const res = await fetch("https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/index_new/en/light_cones.json");
        const data = await res.json();
        
        console.log('Total LCs:', Object.keys(data).length);
        
        const ids = ['23035', '23032'];
        ids.forEach(id => {
            if (data[id]) console.log(`[LC FOUND] ${id}: ${data[id].name}`);
            else console.log(`[LC MISSING] ${id}`);
        });
        
    } catch(e) { console.error(e); }
}

checkLC();
