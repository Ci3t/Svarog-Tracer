/**
 * Test fallback mechanism by using a fake backend URL
 * This simulates backend being down
 */

import { fetchLiveBanners } from './utils/botWarpService.js';

// Temporarily override backend URL to simulate failure
process.env.BACKEND_API_URL = 'http://localhost:9999/api'; // Non-existent server

async function testFallback() {
    console.log('🧪 Testing Fallback Mechanism');
    console.log('Backend URL:', process.env.BACKEND_API_URL);
    console.log('(This should fail and trigger fallback to direct APIs)\n');
    
    console.log('Fetching live banners...\n');
    const banners = await fetchLiveBanners();
    
    console.log('\n📊 Results:');
    console.log('='.repeat(50));
    
    console.log('\nHSR Banners:', banners.hsr.length);
    banners.hsr.forEach(b => console.log(`  - [${b.id}] ${b.name} (${b.type})`));
    
    console.log('\nGenshin Banners:', banners.genshin.length);
    banners.genshin.forEach(b => console.log(`  - [${b.id}] ${b.name} (${b.type})`));
    
    console.log('\nWuWa Banners:', banners.wuwa.length);
    banners.wuwa.forEach(b => console.log(`  - [${b.id}] ${b.name} (${b.type})`));
    
    console.log('\n' + '='.repeat(50));
    
    // Verify fallback worked
    const totalBanners = banners.hsr.length + banners.genshin.length + banners.wuwa.length;
    if (totalBanners > 0) {
        console.log('\n✅ FALLBACK SUCCESSFUL! Bot still works without backend.');
    } else {
        console.log('\n❌ FALLBACK FAILED! No banners returned.');
    }
}

testFallback();
